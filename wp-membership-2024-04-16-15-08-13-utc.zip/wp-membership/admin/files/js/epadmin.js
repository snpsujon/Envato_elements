"use strict";
var ajaxurl = ep_data.ajaxurl;
var loader_image = ep_data.loading_image;
var i=0;
var current_progress = 0;	

jQuery(window).on('load',function(){
	if (jQuery(".epinputdate")[0]){	
		jQuery( ".epinputdate" ).datepicker({ dateFormat: 'dd-mm-yy' } );
	}
});

function edit_profile_image_admin(profile_image_id,user_id){
		var image_gallery_frame;
		image_gallery_frame = wp.media.frames.downloadable_file = wp.media({
		
			
			multiple: false,
			displayUserSettings: true,
		});
		image_gallery_frame.on( 'select', function() {
			var selection = image_gallery_frame.state().get('selection');
			selection.map( function( attachment ) {
				attachment = attachment.toJSON();
				if ( attachment.id ) {					
					var search_params = {
						"action": 	"iv_membership_update_profile_pic_admin",
						"attachment_thum": attachment.sizes.thumbnail.url,
						"profile_pic_url_1": attachment.url,
						"user_id": user_id,
						"_wpnonce":  	ep_data.adminnonce,
					};
					jQuery.ajax({
						url: ajaxurl,
						dataType: "json",
						type: "post",
						data: search_params,
						success: function(response) {
							if(response=='success'){
								jQuery('#'+profile_image_id).html('<img  width="100px"  class=" img-responsive"  src="'+attachment.sizes.thumbnail.url+'">');
							}
						}
					});
				}
			});
		});
		image_gallery_frame.open();
}

function iv_import_medo(){
			 var interval = setInterval(function() {
					current_progress += 10;
					jQuery("#dynamic")
					.css("width", current_progress + "%")
					.attr("aria-valuenow", current_progress)
					.text(current_progress + "% Complete");
					if (current_progress >= 90)
						clearInterval(interval);
				}, 1000);
	var search_params={
			"action"  : "iv_directories_import_data",
			"_wpnonce": 	ep_data.settings,
		};
		jQuery.ajax({					
			url : ajaxurl,					 
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
					current_progress = 90;
					jQuery("#dynamic")
					.css("width", current_progress + "%")
					.attr("aria-valuenow", current_progress)
					.text(current_progress + "% Complete");
					jQuery('#cptlink12').show(1000);
					jQuery('#importbutton').hide(500); 
			}
		})
	}
	function iv_update_csv_settings(){
		jQuery('#update_message_csv_setting').html(loader_image);
		var search_params={
			"action"  : 	"iv_membership_update_csv_setting",
			"form_data":	jQuery("#post_settings_csv").serialize(),
			"_wpnonce":  	ep_data.adminnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#update_message_csv_setting').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		});
	
	}
function update_user_setting() {		
		var search_params={
			"action"  : 	"iv_membership_update_user_settings",
			"form_data":	jQuery("#user_form_iv").serialize(),
			"_wpnonce":  	ep_data.adminnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				var url = ep_data.userredirect ;
				jQuery(location).attr('href',url);
			}
		});
	}
jQuery(window).on('load',function(){
	if (jQuery("#exp_date")[0]){	
		jQuery( "#exp_date" ).datepicker({ dateFormat: 'dd-mm-yy' });
	}	
	if (jQuery("#start_date")[0]){	
		jQuery( "#start_date" ).datepicker({ dateFormat: 'dd-mm-yy' });
	}
	if (jQuery("#end_date")[0]){	
		jQuery( "#end_date" ).datepicker({ dateFormat: 'dd-mm-yy' });
	}	
	});
jQuery(window).on('load',function(){
	if (jQuery("#user-data")[0]){	
		jQuery('#user-data').show();
		var oTable = jQuery('#user-data').dataTable({
			"pageLength": 25
		});
		oTable.fnSort( [ [1,'DESC'] ] );
		
	}	
});

	function iv_update_payment_settings() {	
		var search_params={
			"action"  : 	"iv_membership_update_payment_setting",
			"form_data":	jQuery("#payment_settings").serialize(),
			"_wpnonce":  	ep_data.adminnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#update_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		});
	}
	function iv_update_page_settings(){
		var search_params={
			"action"  : 	"iv_membership_update_page_setting",
			"form_data":	jQuery("#page_settings").serialize(),
			"_wpnonce":  	ep_data.adminnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#update_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		});
	}
	function iv_update_email_settings(){
		var search_params={
			"action"  : 	"iv_membership_update_email_setting",
			"form_data":	jQuery("#email_settings").serialize(),
			"_wpnonce":  	ep_data.adminnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#update_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		});
	}
	function iv_update_mailchamp_settings(){
		var search_params={
			"action"  : 	"iv_membership_update_mailchamp_setting",
			"form_data":	jQuery("#mailchimp_settings").serialize(),
			"_wpnonce":  	ep_data.adminnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#update_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
				location.reload();
			}
		});
	}
	function iv_update_account_settings(){
		var search_params={
			"action"  : 	"iv_membership_update_account_setting",
			"form_data":	jQuery("#account_settings").serialize(),
			"_wpnonce":  	ep_data.adminnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#update_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		});
	}
	function iv_update_post_settings(){
		var search_params={
			"action"  : 	"iv_membership_update_post_setting",
			"form_data":	jQuery("#post_settings").serialize(),
			"_wpnonce":  	ep_data.adminnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#update_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		});
	}
		
	function iv_update_tax_settings(){
		var search_params={
			"action"  : 	"iv_membership_update_tax_setting",
			"form_data":	jQuery("#tax_settings").serialize(),
			"_wpnonce":  	ep_data.adminnonce,
		};
		jQuery.ajax({
			url : ajaxurl,
			dataType : "json",
			type : "post",
			data : search_params,
			success : function(response){
				jQuery('#update_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
				jQuery('#tax_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		})
	}
	function iv_show_common_tax(){
		jQuery('#common_tax').show();
		jQuery('#country_tax').hide();
	}
	function iv_show_country_tax(){
		jQuery('#common_tax').hide();
		jQuery('#country_tax').show();
	}

jQuery(document).ready(function () {
		jQuery("#allredirects").on('click', '.btnDelete', function () { 
			jQuery(this).closest('tr').remove();
			var search_params={
				"action"  : 	"iv_update_protected_page_setting",
				"form_data":	jQuery("#protected_page_table").serialize(),
				"_wpnonce":  	ep_data.adminnonce,
			};
			jQuery.ajax({
				url : ajaxurl,
				dataType : "json",
				type : "post",
				data : search_params,
				success : function(response){
				}
			})
		});
});	
	function iv_update_protected_settings_page(){
		var page_url = jQuery("#page_url").val();
		var notaccessroles = jQuery("#notaccessroles").val();
		var redirectto = jQuery("#redpage").val();
		var redirecttotext = jQuery("#redpage :selected").text();
		var userroles='';
		for (i = 0; i < notaccessroles.length; i++) {
			userroles += notaccessroles[i] + ",";
		}
    if(page_url!=''){
			var newRowContent = '<tr><td>'+page_url+'</td><td>'+userroles+'</td><td>'+redirecttotext+'</td><td><button type="button"  class="btnDelete">Delete</button><input type="hidden" name="url[]" id="url[]" value="'+page_url+'"><input type="hidden" name="roles[]" id="roles[]" value="'+userroles+'"><input type="hidden" name="redirectto[]" id="redirectto[]" value="'+redirectto+'"></td></tr>';
			jQuery(newRowContent).appendTo(jQuery("#allredirects"));
			var search_params={
				"action"  : 	"iv_update_protected_page_setting",
				"form_data":	jQuery("#protected_page_table").serialize(),
				"_wpnonce":  	ep_data.adminnonce,
			};
			jQuery.ajax({
				url : ajaxurl,
				dataType : "json",
				type : "post",
				data : search_params,
				success : function(response){
					jQuery('#protected_page_settings2').trigger("reset");
				}
			})
		}
	}
jQuery(document).ready(function () {
		jQuery("input[name='payment_gateway']").on("click", function(){ 
				iv_update_gateway_settings();
		});
	});
function  iv_update_gateway_settings(){
		var search_params = {
			"action": "iv_membership_gateway_settings_update",
			"payment_gateway": jQuery("input[name=payment_gateway]:checked").val(),
			"_wpnonce":  	ep_data.adminnonce,

		};
		jQuery.ajax({
			url: ajaxurl,
			dataType: "json",
			type: "post",
			data: search_params,
			success: function(response) {
				jQuery('#update_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.msg +'.</div>');
			}
		});
}

jQuery(document).ready(function () {
		jQuery("input[name='option-userdirectory']").on("click", function(){ 
			update_user_directory_template();
		});
	});
	function update_user_directory_template(){
	
		var search_params = {
			"action": 			"iv_membership_update_user_directory",
			"profile-st": jQuery("input[name=option-userdirectory]:checked").val(),
			"_wpnonce":  	ep_data.adminnonce,
		};
		jQuery.ajax({
			url: ajaxurl,
			dataType: "json",
			type: "post",
			data: search_params,
			success: function(response) {
				jQuery('#success_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.code +'.</div>');
			}
		});
	}
jQuery(document).ready(function () {
	jQuery("input[name='option-profile']").on("click", function(){ 
		var search_params = {
		"action": 			"iv_membership_update_profile_public_template",
		"profile-st": jQuery("input[name=option-profile]:checked").val(),	
		"_wpnonce":  	ep_data.adminnonce,
		};
		jQuery.ajax({
			url: ep_data.ajaxurl,
			dataType: "json",
			type: "post",
			data: search_params,
			success: function(response) {
				jQuery('#success_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.code +'.</div>');
			}
		});
	});
});

jQuery(document).ready(function () {
	jQuery("input[name='option-signup']").on("click", function(){ 
		var search_params = {
		"action": 			"iv_membership_update_signup_template",
		"signup-st": jQuery("input[name=option-signup]:checked").val(),	
				"_wpnonce":  	ep_data.adminnonce,
			};
			jQuery.ajax({
				url: ep_data.ajaxurl,
				dataType: "json",
				type: "post",
				data: search_params,
				success: function(response) {  
					jQuery('#update_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.code +'.</div>');			
				}
			});
	});
});

function update_the_package() {
	var loader_image = ep_data.loading_image;
	jQuery("#loading").html(loader_image);
	var search_params={
		"action"  : 	"iv_membership_update_package",	
		"form_data":	jQuery("#package_form_iv").serialize(), 
		"_wpnonce":  	ep_data.adminnonce,
	};
	jQuery.ajax({					
		url : ep_data.ajaxurl,					 
		dataType : "json",
		type : "post",
		data : search_params,
		success : function(response){						
			var url = ep_data.redirecturlpackage;   						
			jQuery(location).attr('href',url);
		}
	});
}
function save_the_form() {
	var loader_image = ep_data.loading_image;
	jQuery("#loading").html(loader_image);
	var search_params={
		"action"  : 	"iv_membership_save_package",	
		"form_data":	jQuery("#package_form_iv").serialize(), 
		"_wpnonce":  	ep_data.adminnonce,
	};
	jQuery.ajax({					
		url : ep_data.ajaxurl,					 
		dataType : "json",
		type : "post",
		data : search_params,
		success : function(response){
			var url = ep_data.redirecturlpackage;						
			jQuery(location).attr('href',url);	
		}
	});
}

jQuery(document).ready(function () {
	jQuery("input[name='package_recurring']").on("click", function(){ 
		if(this.checked){				
		jQuery('#recurring_block').show();
		}else{				
		jQuery('#recurring_block').hide();
	}

	});
});

jQuery(document).ready(function () {
	jQuery("input[name='package_enable_trial_period']").on("click", function(){ 
		if(this.checked){				
		jQuery('#trial_block').show();
		}else{				
		jQuery('#trial_block').hide();
	}

	});
});


function update_stripe_setting() {
	var search_params={
		"action"  : 	"iv_membership_update_stripe_settings",	
		"form_data":	jQuery("#stripe_form_iv").serialize(), 
		"_wpnonce":  	ep_data.adminnonce,
	};
	jQuery.ajax({					
		url : ep_data.ajaxurl,				 
		dataType : "json",
		type : "post",
		data : search_params,
		success : function(response){
			jQuery('#iv-loading').html('<div class="col-md-12 alert alert-success">Update Successfully. <a class="btn btn-success btn-xs" href="?page=wp-iv_membership-payment-settings"> Go Payment Setting Page</a></div>');
		}
	});
}
function update_paypal_setting() {
	var search_params={
		"action"  : 	"iv_membership_update_paypal_settings",	
		"form_data":	jQuery("#paypal_form_iv").serialize(), 
		"_wpnonce":  	ep_data.adminnonce,
	};
	jQuery.ajax({					
		url : ep_data.ajaxurl,				 
		dataType : "json",
		type : "post",
		data : search_params,
		success : function(response){
			jQuery('#iv-loading').html('<div class="col-md-5 alert alert-success">Update Successfully. <a class="btn btn-success btn-xs" href="?page=wp-iv_membership-payment-settings"> Go Payment Setting Page</aa></div>');
		}
	});
}
jQuery(document).ready(function () {
	jQuery("input[name='option-price-table']").on("click", function(){ 
			var search_params = {
				"action": 			"iv_membership_update_price_table_template",
				"price-tab-style": jQuery("input[name=option-price-table]:checked").val(),	
				"_wpnonce":  	ep_data.adminnonce,
			};
			jQuery.ajax({
				url: ep_data.ajaxurl,
				dataType: "json",
				type: "post",
				data: search_params,
				success: function(response) {              										
					jQuery('#success_message').html('<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'+response.code +'.</div>');
				}
			});
	});
});

function iv_package_status_change(status_id,curr_status){		
	status_id =status_id.trim();
	curr_status=curr_status.trim();					
	var search_params = {
		"action": 	"iv_membership_update_package_status",
		"status_id": status_id,	
		"status_current":curr_status,
		"_wpnonce":  	ep_data.adminnonce,
	};
	jQuery.ajax({
		url: ep_data.ajaxurl,
		dataType: "json",
		type: "post",
		data: search_params,
		success: function(response) {   
			if(response.code=='success'){	
				jQuery("#status_"+status_id).html('<button class="btn btn-info btn-xs" onclick="return iv_package_status_change(\' '+status_id+' \' ,\' '+response.current_st+' \');">'+response.msg+'</button>');
			}								
		}
	});
}	
function iv_create_coupon() {				
	var search_params={
		"action"  : 	"iv_membership_create_coupon",	
		"form_data":	jQuery("#coupon_form_iv").serialize(), 
		"form_pac_ids": jQuery("#package_id").val(),
		"_wpnonce":  	ep_data.adminnonce,
	};
	jQuery.ajax({					
		url : ep_data.ajaxurl,					 
		dataType : "json",
		type : "post",
		data : search_params,
		success : function(response){
			var url = ep_data.redirecturlcoupon;    						
			jQuery(location).attr('href',url);
		}
	});				
}	
function iv_update_coupon() {
	var search_params={
		"action"  : 	"iv_membership_update_coupon",	
		"form_data":	jQuery("#coupon_form_iv").serialize(), 
		"form_pac_ids": jQuery("#package_id").val(),
		"_wpnonce":  	ep_data.adminnonce,
	};
	jQuery.ajax({					
		url : ep_data.ajaxurl,				 
		dataType : "json",
		type : "post",
		data : search_params,
		success : function(response){
			var url = ep_data.redirecturlcoupon;    									
			jQuery(location).attr('href',url);
		}
	});
}