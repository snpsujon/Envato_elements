<?php

namespace Stripe\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
