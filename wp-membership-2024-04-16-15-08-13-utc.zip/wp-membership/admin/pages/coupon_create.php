<div class="bootstrap-wrapper">
	<div class="dashboard-eplugin container-fluid">
		<div class="row">
			<div class="col-md-12" id="submit-button-holder">
				<div class="pull-right"><button class="btn btn-info btn-lg" onclick="return iv_create_coupon();"><?php esc_html_e('Save Coupon','wpmembership');?></button></div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12"><h3 class="page-header"><?php esc_html_e('Create New Coupon','wpmembership');?> </h3>
			</div>
		</div>
		<form id="coupon_form_iv" name="coupon_form_iv" class="form-horizontal" role="form" onsubmit="return false;">
			<div class="form-group">
				<label for="text" class="col-md-2 control-label"></label>
				<div id="iv-loading"></div>
			</div>
			<div class="form-group">
				<label for="text" class="col-md-2 control-label"><?php esc_html_e('Coupon Name','wpmembership');?></label>
				<div class="col-md-5">
					<input type="text" class="form-control" name="coupon_name" id="coupon_name" value="" placeholder="<?php esc_html_e('Enter Coupon Name Or Coupon Code','wpmembership');?>">
				</div>
			</div>
			<div class="form-group">
				<label for="text" class="col-md-2 control-label"><?php esc_html_e('Discount Type','wpmembership');?></label>
				<div class="col-md-5">
					<select  name="coupon_type" id ="coupon_type" class="form-control">
						<option value="amount" ><?php esc_html_e('Fixed Amount','wpmembership');?></option>
						<option value="percentage" ><?php esc_html_e('Percentage','wpmembership');?></option>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label for="text" class="col-md-2 control-label"><?php esc_html_e('Package Only','wpmembership');?></label>
				<div class="col-md-5">
					<?php
						echo'<select multiple name="package_id" id ="package_id" class="form-control">';
						$args = array(
						'post_type' => 'iv_membership_pack', 
						'posts_per_page'=> '999',  
						'post_status'=>'draft',
						'orderby' => 'date',
						'order' => 'ASC',
						);
						$ep_query = new WP_Query( $args );
						if ( $ep_query->have_posts() ) :
						while ( $ep_query->have_posts() ) : $ep_query->the_post();
						$epid = get_the_ID();
						$recurring= get_post_meta( $epid,'iv_membership_package_recurring',true);
						$pac_cost= get_post_meta( $epid,'iv_membership_package_cost',true);
						if($recurring!='on' and $pac_cost!="" ){
							echo '<option value="'. $epid.'" selected >'. get_the_title().'</option>';
						}
						endwhile;
						endif;
						echo '</select>';
					?>
				</div>
			</div>
			<div class="form-group">
				<label for="inputEmail3" class="col-md-2 control-label"><?php esc_html_e('Usage Limit','wpmembership');?></label>
				<div class="col-md-5">
					<input type="text" class="form-control" id="coupon_count" name="coupon_count" value=""  placeholder="<?php esc_html_e('Enter Usage Limit Number','wpmembership');?>" value="999999">
				</div>
			</div>
			<div class="form-group" >
				<label for="text" class="col-md-2 control-label"><?php esc_html_e('Start Date','wpmembership');?></label>
				<div class="col-md-5">
					<input type="text"  name="start_date"  readonly   id="start_date" class="form-control ctrl-textbox"  placeholder="<?php esc_html_e('Select Date','wpmembership');?>">
				</div>
			</div>
			<div class="form-group">
				<label for="inputEmail3" class="col-md-2 control-label"><?php esc_html_e('Expire Date','wpmembership');?></label>
				<div class="col-md-5">
					<input type="text" class="form-control" readonly id="end_date" name="end_date" value=""  placeholder="<?php esc_html_e('Select Date','wpmembership');?>">
				</div>
			</div>
			<div class="form-group">
				<label for="inputEmail3" class="col-md-2 control-label"><?php esc_html_e('Amount','wpmembership');?></label>
				<div class="col-md-5">
					<input type="text" class="form-control" id="coupon_amount" name="coupon_amount" value=""  placeholder=" <?php esc_html_e('Coupon Amount [ Only Amount no Currency ]','wpmembership');?>">
				</div>
			</div>
		</form>
		<div class="row">
			<div class="col-xs-12">
				<div align="center">
					<button class="btn btn-info btn-lg" onclick="return iv_create_coupon();"><?php esc_html_e('Save Coupon','wpmembership');?></button>
				</div>
				<p>&nbsp;</p>
			</div>
		</div>
		<div class=" col-md-7  bs-callout bs-callout-info">
			<?php esc_html_e('Note : Coupon will work on "One Time Payment" only. Coupon will not work on recurring payment and 100% discount.','wpmembership');?>
		</div>
	</div>
</div>
