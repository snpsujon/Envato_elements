<div class="row">
<div class="col-md-4">
<div id="update_message_csv_setting"></div>
	<form class="form-horizontal" role="form"  name='post_settings_csv' id='post_settings_csv'>
							
							<div class="form-group">
								<h3  class="col-md-12   page-header"><?php esc_html_e('User Settings','wpmembership'); ?> </h3>
							</div>
							<div class="form-group">
								<label  class="col-md-3   control-label"><?php esc_html_e('Set user Role for the CSV importer:','wpmembership'); ?> </label>
								
								<?php
								$iv_membership_csv_role = get_option( 'iv_membership_csv_role');
							?>
								<div class="checkbox col-md-9 ">
									<select name="user_role" id ="user_role" class="form-control">
										<?php
											foreach ( $wp_roles->roles as $key=>$value ){
												echo'<option value="'.esc_html($key).'"  '.($iv_membership_csv_role==$key? " selected" : " ") .' >'.esc_html($key).'</option>';
											}
										?>
									</select>
								</div>
							</div>
							<div class="form-group ">
							<?php
								 $user_get_email = get_option( 'user_csv_get_email');
							?>
								<label  class="col-md-3   control-label"></label>
								<label  class="col-md-9   pull-left"><?php esc_html_e('User get email:','wpmembership'); ?> 
										<input  class="  " type="checkbox" name="user_csv_get_email" id="user_csv_get_email" value="yes" <?php echo ($user_get_email=='yes'? 'checked':'' ); ?> > 										
								</label>
							</div>
							
	</form>
	<div class="form-group row">
		<label  class="col-md-3 control-label"> </label>
		<div class="col-md-8">
			<button type="button" onclick="return iv_update_csv_settings();" class="btn btn-success"><?php esc_html_e('Update','wpmembership'); ?></button>
		</div>
	</div>
</div>
	<div class="col-md-8">
	<div class="form-group">
		<h3  class="col-md-12   page-header"><?php esc_html_e('CSV Upload','wpmembership'); ?> </h3>
	</div>
		<div class="" id="erp_update_message"></div>
		<div class="row bs-wizard" >
			<div id="step-1" class="col-md-3 bs-wizard-step   ">
				<div class="text-center bs-wizard-stepnum"><?php esc_html_e('Step 1','wpmembership'); ?></div>
				<div class="progress"><div class="progress-bar"></div></div>
				<a href="#" class="bs-wizard-dot"></a>
				<div class="bs-wizard-info text-center">
					<?php esc_html_e('Upload CSV File','wpmembership'); ?>
				</div>
			</div>
			<div id="step-2" class="col-md-3 bs-wizard-step disabled">
				<div class="text-center bs-wizard-stepnum"><?php esc_html_e('Step 2','wpmembership'); ?></div>
				<div class="progress"><div class="progress-bar"></div></div>
				<a href="#" class="bs-wizard-dot"></a>
				<div class="bs-wizard-info text-center">
					<?php esc_html_e('Column mapping','wpmembership'); ?>
				</div>
			</div>
			<div id="step-3" class="col-md-3 bs-wizard-step disabled ">
				<div class="text-center bs-wizard-stepnum"><?php esc_html_e('Step 3','wpmembership'); ?></div>
				<div class="progress"><div class="progress-bar"></div></div>
				<a href="#" class="bs-wizard-dot"></a>
				<div class="bs-wizard-info text-center">
					<span><?php esc_html_e('Import','wpmembership'); ?></span>
				</div>
			</div>
			<div id="step-4" class="col-md-3 bs-wizard-step disabled">
				<div class="text-center bs-wizard-stepnum"><?php esc_html_e('Step 4','wpmembership'); ?></div>
				<div class="progress"><div class="progress-bar"></div></div>
				<a href="#" class="bs-wizard-dot"></a>
				<div class="bs-wizard-info text-center">
					<?php esc_html_e('Done!','wpmembership'); ?>
				</div>
			</div>
		</div>
		<div id="ep1">	
			<center>
				<button type="button" onclick="upload_csv_file('gallery_doc_div');" class="btn btn-success" > <?php esc_html_e('Upload CSV File','wpmembership'); ?></button>
			</center>
			<div class="" id="uploaded_csv_file_name"></div>
			<input type="hidden" name="erp_csv_id" id="erp_csv_id" value="">
			<hr/>
			<center>		
				<p><?php esc_html_e('This tool allows you to import (or merge) user data to your site from a CSV file.','wpmembership'); ?></p>
				<p><?php esc_html_e('If CSV ID filed value match your user ID then it will update/merge','wpmembership'); ?></p>
				<a class="btn btn-info btn-xs" href="<?php echo  WP_iv_membership_URLPATH; ?>assets/sample-data.csv" download ><?php esc_html_e('Sample CSV File','wpmembership'); ?></a>
			</center>
		</div>
		<div id="ep2" class="none">
			<div id="data_maping"></div>
			<center>
				<button type="button" onclick="save_csv_file_to_database();"  class="btn btn-success" ><?php  esc_html_e('Run The importer','wpmembership');?></button>
			</center>
		</div>
		<div id="ep3" class="none">
			<center>
				<img src="<?php echo WP_iv_membership_URLPATH; ?>admin/files/images/loader.gif">
				<div class="progress" >
					<div class="progress-bar progress-bar-striped progress-bar-animated" id="progress-bar-csv" >0%</div>
				</div>
			</center>
		</div>
		<div id="ep4" class="none">
			<center>
				<h2><?php esc_html_e('Done!','wpmembership'); ?></h2>
			</center>
		</div>
	</div>
</div>

<?php
wp_enqueue_media();
	wp_enqueue_script('iv_directory-ar-script-30', WP_iv_membership_URLPATH . 'admin/files/js/csv-import.js');
	wp_localize_script('iv_directory-ar-script-30', 'dirpro_data', array(
	'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.WP_iv_membership_URLPATH.'admin/files/images/loader.gif">',	
	'dirwpnonce'=> wp_create_nonce("csv"),
	) );
?>