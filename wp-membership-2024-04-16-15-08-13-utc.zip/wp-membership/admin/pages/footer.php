<div class=" col-md-12  bs-callout bs-callout-info"><span>
	<a class="btn btn-danger btn-sm " href="https://www.youtube.com/playlist?list=PLLRcfoNnzUb5XW7-kbt-nPCYit7-CnBFv" target="_blank"><?php esc_html_e('Video Tutorials','wpmembership');?></a> </span> 
	<span><a class="btn btn-warning btn-sm " href="https://codecanyon.net/item/wp-membership/10066554/comments" target="_blank"><?php esc_html_e('Support','wpmembership');?></a> </span> 
	<span><a class="btn btn-success btn-sm " href="http://help.eplug-ins.com/wpmdoc/" target="_blank" ><?php esc_html_e('Doc','wpmembership');?></a> </span>
</div>