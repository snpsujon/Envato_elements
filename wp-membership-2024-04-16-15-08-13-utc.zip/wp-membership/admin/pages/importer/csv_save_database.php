<?php
	global $current_user;
	
	$main_class = new WP_iv_membership;
	$csv_role=get_option('iv_membership_csv_role' );
	
	$csv =  get_attached_file($csv_file_id) ;
	$eppro_total_row = floatval( get_option( 'eppro_total_row' ));	
	$default_fields = array();
	$field_set=get_option('iv_membership_profile_fields' );
	if($field_set!=""){ 
		$default_fields=get_option('iv_membership_profile_fields' );
		}else{															
		$default_fields['first_name']='First Name';
		$default_fields['last_name']='Last Name';
		$default_fields['phone']='Phone Number';								
		$default_fields['address']='Address';
		$default_fields['city']='City';
		$default_fields['zipcode']='Zipcode';
		$default_fields['country-userprofile']='Country';
		$default_fields['job_title']='Job title';
		$default_fields['gender']='Gender';
		$default_fields['occupation']='Occupation';
		$default_fields['description']='About';
		$default_fields['web_site']='Website Url';
	}
	$done_status='not-done';
	$row=$row_start;
	$row_max=$row+2;
	$iii=1;
	if (($handle = fopen($csv, 'r' )) !== FALSE) {					
		$top_header = fgetcsv($handle,1000, ",");
		while (($data = fgetcsv($handle)) !== FALSE) {
			if($iii>=$row  AND $row<$row_max){	
				$i=0;
				$user_id=0; $post_data=array();
				foreach($data as $one_col){
					if(in_array("ID", $top_header) OR in_array("Id", $top_header) OR in_array("id", $top_header)){
						// Check ID 
						if(strtolower($top_header[$i])=='id'){		
							if(trim($one_col)!=''){
								$user_check=get_userdata($one_col);													
								if ( isset($user_check->ID) ) {								
										$user_id=$one_col;	
									}else{
										$user_id=0;								
								}							
							}
							}else{						
							$top_header_i=str_replace (' ','-', $top_header[$i]);						
							$post_data[$form_data[$top_header_i]]=$one_col;
						}					
						}else{					
						$top_header_i=str_replace (' ','-', $top_header[$i]);					
						$post_data[$form_data[$top_header_i]]=$one_col;					
						$user_id=0;
					}
					$i++;
				}
				if($user_id==0){
					// Insert user
						if(isset($post_data['username'])){
							$userdata['user_login']=sanitize_text_field($post_data['username']);
						}if(isset($post_data['email'])){
							$userdata['user_email']=sanitize_email($post_data['email']);
						}
						if(isset($post_data['password'])){
							$userdata['user_pass']=sanitize_text_field($post_data['password']);
						}	
						$user_id = wp_insert_user( $userdata ) ;
						$user = new WP_User( $user_id );
						$user->set_role($csv_role);		
						
					}else{
						$userdata=array();				
						$userdata['user_pass']=sanitize_text_field($post_data['password']);
						wp_update_user($userdata);
				}
				
				if(isset($post_data['profile-image'])){
					if(strlen(trim($post_data['profile-image']))>3){						
						update_user_meta($user_id, 'iv_profile_pic_thum', sanitize_text_field($post_data['profile-image'])); 	
					}	
				}	
				
				
				if(isset($post_data['payment_status'])){
					update_user_meta($user_id, 'iv_membership_payment_status', sanitize_text_field($post_data['payment_status'])); 				
				}
				if(isset($post_data['exprie_date'])){
					update_user_meta($user_id, 'iv_membership_exprie_date', sanitize_text_field($post_data['exprie_date'])); 				
				}
				if(isset($post_data['payment_gateway'])){
					update_user_meta($user_id, 'iv_membership_payment_gateway', sanitize_text_field($post_data['payment_gateway']));
				}
				if(isset($post_data['paypal_recurring_profile_id'])){
					update_user_meta($user_id, 'iv_paypal_recurring_profile_id', sanitize_text_field($post_data['paypal_recurring_profile_id']));
				}
				if(isset($post_data['package_id'])){
					update_user_meta($user_id, 'iv_membership_package_id', sanitize_text_field($post_data['package_id']));
				}
				if(isset($post_data['stripe_cust_id'])){
					update_user_meta($user_id, 'iv_membership_stripe_cust_id', sanitize_text_field($post_data['stripe_cust_id']));
				}
				if(isset($post_data['stripe_subscrip_id'])){
						update_user_meta($user_id, 'iv_membership_stripe_subscrip_id', sanitize_text_field($post_data['stripe_subscrip_id']));
				}
				if(isset($post_data['facebook'])){
						update_user_meta($user_id, 'facebook', sanitize_text_field($post_data['facebook']));
				}
				if(isset($post_data['linkedin'])){
						update_user_meta($user_id, 'linkedin', sanitize_text_field($post_data['linkedin']));
				}
				if(isset($post_data['twitter'])){
						update_user_meta($user_id, 'twitter', sanitize_text_field($post_data['twitter']));
				}
				if(isset($post_data['instagram'])){
						update_user_meta($user_id, 'instagram', sanitize_text_field($post_data['instagram']));
				}
				if(isset($post_data['pinterest'])){
						update_user_meta($user_id, 'pinterest', sanitize_text_field($post_data['pinterest']));
				}				
				if(isset($post_data['youtube'])){
					update_user_meta($user_id, 'youtube', sanitize_text_field($post_data['youtube'])); 				
				}
				
				if(sizeof($default_fields )){			
					foreach( $default_fields as $field_key => $field_value ) { 
						update_user_meta($user_id, $field_key, $post_data[$field_key] );							
					}					
				}
				$row++;
				update_option( 'eppro_current_row',$row);	
			}		
			$iii++;	
		}
	}
	$row_done=$row_max;
	if($row_max >=$eppro_total_row){$done_status='done';}
	fclose($handle);
?>