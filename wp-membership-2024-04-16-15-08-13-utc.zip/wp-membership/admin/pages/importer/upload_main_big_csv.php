<?php

	$csv = file_get_contents( get_attached_file($csv_file_id) );
	if($csv === false){	
		$url=get_attached_file($csv_file_id);
		$ch = curl_init();
		curl_setopt ($ch, CURLOPT_URL, $url);
		curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 5);
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
		$csv = curl_exec($ch);
	}
	$csv_rows = explode( "\n", $csv );
	$total_rows = count( $csv_rows );
	$title_row = $csv_rows[ 0 ];
	update_option( 'eppro_total_row',$total_rows-1);	
	update_option( 'eppro_current_row','1');	
	$title_row_array= explode(",",$title_row);
	$main_fields =array('id','username','email','password','profile-image','payment_status','exprie_date','payment_gateway','paypal_recurring_profile_id', 'package_id','stripe_cust_id','stripe_subscrip_id','facebook','linkedin','twitter','instagram','pinterest','youtube');
	$maping='';
	$default_fields = array();
	$field_set=get_option('iv_membership_profile_fields' );
	if($field_set!=""){ 
		$default_fields=get_option('iv_membership_profile_fields' );
		}else{															
		$default_fields['first_name']='First Name';
		$default_fields['last_name']='Last Name';
		$default_fields['phone']='Phone Number';								
		$default_fields['address']='Address';
		$default_fields['city']='City';
		$default_fields['zipcode']='Zipcode';
		$default_fields['country-userprofile']='Country';
		$default_fields['job_title']='Job title';
		$default_fields['gender']='Gender';
		$default_fields['occupation']='Occupation';
		$default_fields['description']='About';
		$default_fields['web_site']='Website Url';
	}
	if(sizeof($default_fields )){			
		foreach( $default_fields as $field_key => $field_value ) { 
			array_push($main_fields, $field_key);
		}					
	}
	$i=0;
	$maping=$maping.'<form id="csv_maping" name="csv_maping" ><table class="table  table-striped">
	<thead>
    <tr>    
	<th>'.esc_html__('User Field/Map to field', 'wpmembership' ).'</th>
	<th>'.esc_html__('CSV Column Title/Name', 'wpmembership' ).'</th>      
    </tr>
	</thead>';
	foreach($title_row_array as $one_col){
		$sel_name= str_replace (' ','-', $one_col);
		$maping=$maping.'<tr><td><select name="'.trim($sel_name).'">';
		$maping=$maping.'<option value="">'.esc_html__('Email', 'wpmembership' ).'</option>';
		$ii=0;
		foreach($main_fields as $main_one){		
			$maping=$maping.'<option value="'.esc_attr($main_one).'" '.($i==$ii?' selected':"").'>'.esc_html($main_one).'</option>';		
			$ii++;
		}	
		$maping=$maping.'</select></td>';
		$maping=$maping.'<td>'.$one_col.'<input type="hidden" name="column'.$i.'" value="'.esc_attr($one_col).'"></td>';
		$maping=$maping.'</tr>';	
		$i++;	
	}
	$maping=$maping.'</table></form>';
?>