<?php
	global $post;
	
	add_action( 'manage_wpmembership_message_posts_custom_column' , 'wpmembership_custom_wpmembership_message_column' );
	add_filter( 'manage_edit-wpmembership_message_columns',  'wpmembership_set_custom_edit_wpmembership_message_columns'  );
	function wpmembership_set_custom_edit_wpmembership_message_columns($columns) {				
		$columns['Message'] = esc_html__('Message','wpmembership');
		$columns['email'] = esc_html__('Email','wpmembership');
		$columns['phone'] = esc_html__('Phone','wpmembership');		
		return $columns;
	}
	function wpmembership_custom_wpmembership_message_column( $column ) {
		global $post;
		switch ( $column ) {
			case 'Message' :		
				echo esc_html($post->post_content);
			break; 
			case 'phone' :			
				echo get_post_meta($post->ID,'from_phone',true);  
			break;
			case 'email' :
				echo get_post_meta($post->ID,'from_email',true);  
			break;
			
			
		}
	}	
	
?>