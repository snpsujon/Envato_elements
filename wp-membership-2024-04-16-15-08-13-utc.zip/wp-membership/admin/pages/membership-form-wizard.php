<div class="bootstrap-wrapper">
	<div class="dashboard-eplugin container-fluid">
		<div class="row">
			<div class="col-md-12">
				<h3 class="" ><?php esc_html_e('Signup Wizard','wpmembership');?> <small> <?php esc_html_e('User Registration & Payment Form','wpmembership');?> </small> </h3>
				<div class="col-md-12" id="update_message">
				</div>
			</div>
		</div>
		<div class="panel panel-info">
			<div class="panel-body">
				<ul class="list-group col-md-6">
					<li class="list-group-item"><?php esc_html_e('Short Code','wpmembership');?> : <code>[iv_membership_form_wizard]  </code></li>
					<li class="list-group-item">PHP Code :<code>
						&lt;?php
						echo do_shortcode('[iv_membership_form_wizard]');
					?&gt;</code>
					</li>
					<li class="list-group-item"> <?php esc_html_e('Signup Page','wpmembership');?>  :
						<?php
							$form_wizard=get_option('_iv_membership_registration');
						?>
						<a class="btn btn-info btn-xs " href="<?php echo get_permalink( $form_wizard ); ?>" target="blank"><?php esc_html_e('View Page','wpmembership');?></a>
					</li>
				</ul>
			</div>
		</div>
		<div class="form-group col-md-12 row">
			<br/>
			<?php
				if(get_option('iv_membership_signup-template')){
					$opt_style=	get_option('iv_membership_signup-template');
					}else{
					$opt_style=	'signup-style-1';
				}
			?>
			<div id="update_message"> </div>
			<table class="table table-striped">
				<tr>
					<td width="15%">
						<label >
							<input type="radio" name="option-signup" id="option-signup" value="signup-style-1" <?php  echo ($opt_style=='signup-style-1' ? 'checked': ''); ?>>
							<?php esc_html_e('Style 1','wpmembership');?>
						</label>
					</td>
					<td width="85%">
						<img src="<?php echo WP_iv_membership_URLPATH.'admin/files/images/User_Registration_1.png'; ?>">
					</td>
				</tr>
				<tr>
					<td>
						<label >
							<input type="radio" name="option-signup" id="option-signup" value="signup-style-2"  <?php  echo ($opt_style=='signup-style-2' ? 'checked': ''); ?> >
							<?php esc_html_e('Style 2', 'wpmembership'); ?>
						</label>
					</td>
					<td>
						<img src="<?php echo WP_iv_membership_URLPATH.'admin/files/images/User_Registration_2.png'; ?>">
					</td>
				</tr>
			</table>
		</div>
	</div>
	</div>