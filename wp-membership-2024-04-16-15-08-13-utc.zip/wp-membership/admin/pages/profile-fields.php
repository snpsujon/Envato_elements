<?php
	$ii=1;
	global $wp_roles;
?>
<div class="bootstrap-wrapper">
	<div class="dashboard-eplugin container-fluid">
		<div class="row">
			<div class="col-xs-12" id="submit-button-holder">
				<div class="pull-right"><button class="btn btn-info btn-lg" onclick="return update_profile_fields();"><?php esc_html_e('Update','wpmembership');?></button>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12"><h3 class="page-header"><?php esc_html_e('Update Profile Setting','wpmembership');?><br /><small> &nbsp;</small> </h3>
			</div>
			<?php
		include('footer.php');
		?>
		</div>
		<form id="profile_fields" name="profile_fields" class="form-horizontal" role="form" onsubmit="return false;">
			
	
		<div class="panel panel-info">
				<div class="panel-heading"><h4><?php esc_html_e('Registration / User Profile Fields','wpmembership');?></h4></div>
				<div class="panel-body">
					<table id="all_fieldsdatatable" name="all_fieldsdatatable"  class="display table" width="100%">					
						<thead>
							<tr>
								<th> <?php  esc_html_e('Input Name','wpmembership')	;?> </th>
								<th> <?php  esc_html_e('Label','wpmembership')	;?> </th>
								<th> <?php  esc_html_e('Type','wpmembership')	;?> </th>
								<th> <?php  esc_html_e('Value[Dropdown,checkbox & Radio Button]','wpmembership')	;?> </th>
								<th> <?php  esc_html_e('User Role [Show on My Account/Profile]','wpmembership')	;?> </th>						
								<th> <?php  esc_html_e('Registration','wpmembership')	;?></th>
								<th> <?php  esc_html_e('My Account / Profile','wpmembership')	;?> </th>
								<th> <?php  esc_html_e('Require','wpmembership')	;?> </th>
								<th><?php  esc_html_e('Action','wpmembership')	;?></th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>
									<?php  esc_html_e('User Profile Pic Uploader','wpmembership');
											$iv_membership_signup_profile_pic=get_option('iv_membership_signup_profile_pic');
											if($iv_membership_signup_profile_pic=='' ){ $iv_membership_signup_profile_pic='yes';	}		
											?>
									</td>
									<td> </td>
									<td> </td>
									<td> </td>
									<td> </td>
									<td> <label>
											<input type="checkbox" name="signup_profile_pic" id="signup_profile_pic" value="yes" <?php echo($iv_membership_signup_profile_pic=='yes'? 'checked':'' );?> >
										</label></td>
									<td> </td>
									<td> </td>
									<td> </td>
							</tr>	
							<tr  >
									<td>
										<?php  esc_html_e('Country for Active Tax On Registration','wpmembership')	;
											$tax_active_module=get_option('_iv_membership_active_tax');
											if($tax_active_module=='' ){ $tax_active_module='yes';	}
											?>
									</td>
									<td> </td>
									<td> </td>
									<td> </td>
									<td> </td>
									<td> <label>
											<input type="checkbox" name="signup_country" id="signup_country" value="yes" <?php echo($tax_active_module=='yes'? 'checked':'' );?> >
										</label></td>
									<td> </td>
									<td> </td>
									<td> </td>
							</tr>	
							<tr  >
									<td>
										<?php  esc_html_e('Terms CheckBox','wpmembership')	;
											$iv_membership_payment_terms=get_option('iv_membership_payment_terms');
											if($iv_membership_payment_terms=='' ){ $iv_membership_payment_terms='yes';	}
											?>
									</td>
									<td> </td>
									<td> </td>
									<td> </td>
									<td> </td>
									<td> <label>
											<input type="checkbox" name="iv_membership_payment_terms" id="iv_membership_payment_terms" value="yes" <?php echo($iv_membership_payment_terms=='yes'? 'checked':'' );?> >
										</label></td>
									<td> </td>
									<td> </td>
									<td> </td>
							</tr>	
							<tr  >
									<td>
										<?php  esc_html_e('Coupon Buton','wpmembership')	;
											$iv_membership_payment_coupon=get_option('_iv_membership_payment_coupon');
											if($iv_membership_payment_coupon=='' ){ $iv_membership_payment_coupon='yes';	}
											?>
									</td>
									<td> </td>
									<td> </td>
									<td> </td>
									<td> </td>
									<td> <label>
											<input type="checkbox" name="iv_membership_payment_coupon" id="iv_membership_payment_coupon" value="yes" <?php echo($iv_membership_payment_coupon=='yes'? 'checked':'' );?> >
										</label></td>
									<td> </td>
									<td> </td>
									<td> </td>
							</tr>	
							<?php
							
								
								$default_fields = array();
								$field_set=get_option('iv_membership_profile_fields' );
								if($field_set!=""){
									$default_fields=get_option('iv_membership_profile_fields' );
									}else{
									$default_fields['first_name']='First Name';
									$default_fields['last_name']='Last Name';
									$default_fields['phone']='Phone Number';
									$default_fields['mobile']='Mobile Number';
									$default_fields['address']='Address';
									$default_fields['city']='City';
									$default_fields['zipcode']='Zipcode';
									$default_fields['country-userprofile']='Country';
									$default_fields['job_title']='Job title';
									$default_fields['gender']='Gender';
									$default_fields['occupation']='Occupation';
									$default_fields['description']='About';
									$default_fields['web_site']='Website Url';
								}
								$i=0;								
								$field_type=  	get_option( 'iv_membership_field_type' );
								$field_type_value=  	get_option( 'iv_membership_field_type_value' );
								$field_type_roles=  	get_option( 'iv_membership_field_type_roles' );
								$sign_up_array=  get_option( 'iv_membership_signup_fields' );
								$myaccount_fields_array=  get_option( 'iv_membership_myaccount_fields' );
								$require_array=  get_option( 'iv_membership_signup_require' );								
								
								
								
								foreach ( $default_fields as $field_key => $field_value ) {
									$sign_up='';									
									if(isset($sign_up_array[$field_key]) && $sign_up_array[$field_key] == 'yes') {
										$sign_up=$sign_up_array[$field_key] ;
									}
									$require='';
									if(isset($require_array[$field_key]) && $require_array[$field_key] == 'yes') {
										$require=$require_array[$field_key];
									}
									$myaccount_one='';									
									if(isset($myaccount_fields_array[$field_key]) && $myaccount_fields_array[$field_key] == 'yes') {
										$myaccount_one=$myaccount_fields_array[$field_key];
									}
									
									
								?>
								<tr  id="wpdatatablefield_<?php echo esc_attr($i);?>">
									<td>
										<input type="text" class="form-control" name="meta_name[]" id="meta_name[]" value="<?php echo esc_attr($field_key); ?>"> 
									</td>
									<td>
										<input type="text" class="form-control" name="meta_label[]" id="meta_label[]" value="<?php echo esc_attr($field_value);?>" >
									</td>
									<td id="inputtypell_<?php echo esc_attr($i);?>">
										
										<?php $field_type_saved= (isset($field_type[$field_key])?$field_type[$field_key]:'' );?>
										<select class="form-select" name="field_type[]" id="field_type[]">
											<option value="text" <?php echo ($field_type_saved=='text'? "selected":'');?> ><?php esc_html_e('Text','wpmembership');?></option>
											<option value="textarea" <?php echo ($field_type_saved=='textarea'? "selected":'');?> ><?php esc_html_e('Text Area','wpmembership');?></option>
											<option value="dropdown" <?php echo ($field_type_saved=='dropdown'? "selected":'');?> ><?php esc_html_e('Dropdown','wpmembership');?></option>
											<option value="radio" <?php echo ($field_type_saved=='radio'? "selected":'');?> ><?php esc_html_e('Radio button','wpmembership');?></option>
											<option value="datepicker" <?php echo ($field_type_saved=='datepicker'? "selected":'');?> ><?php esc_html_e('Date Picker','wpmembership');?></option>
											<option value="checkbox" <?php echo ($field_type_saved=='checkbox'? "selected":'');?> ><?php esc_html_e('Checkbox','wpmembership');?></option>
											<option value="url" <?php echo ($field_type_saved=='url'? "selected":'');?> ><?php esc_html_e('URL','wpmembership');?></option>
										</select>
										
									</td>
									<td>
										<textarea class="form-control" rows="3" name="field_type_value[]" id="field_type_value[]" placeholder="<?php  esc_html_e('Separated by comma','wpmembership');?> "><?php echo esc_attr((isset($field_type_value[$field_key])?$field_type_value[$field_key]:''));?></textarea>
									</td>
									<td id="roleall_<?php echo esc_attr($i);?>">									
									<?php $field_user_role_saved= $field_type_roles[$field_key];
										if($field_user_role_saved==''){$field_user_role_saved=array('all');}
										
										?>									
									<select name="field_user_role<?php echo esc_attr($i);?>[]" multiple="multiple" class="form-select" size="5">
										<option value="all" <?php echo (in_array('all',$field_user_role_saved)? "selected":'');?>> <?php esc_html_e('All Users','wpmembership');?> </option>
										<?php										
											foreach ( $wp_roles->roles as $key_role=>$value_role ){?>
												<option value="<?php echo esc_attr($key_role); ?>" <?php echo (in_array($key_role,$field_user_role_saved)? "selected":'');?>> <?php echo esc_html($key_role);?> </option>
											
											<?php												
											}
										?>
									</select>
										
									</td>
									
									<td>
										<label>
											<input type="checkbox" name="signup<?php echo esc_attr($i); ?>" id="signup<?php echo esc_attr($i); ?>" value="yes" <?php echo($sign_up=='yes'? 'checked':'' );?> >
										</label>
									</td>
									<td>
									
										<label>
											<input type="checkbox" name="myaccountprofile<?php echo esc_attr($i); ?>" id="myaccountprofile<?php echo esc_attr($i); ?>" value="yes" <?php echo ($myaccount_one=='yes'? 'checked':'' );?>  class="text-center">
										</label>
									</td>
									<td>
										<label>
											<input type="checkbox" name="srequire<?php echo esc_attr($i); ?>" id="srequire<?php echo esc_attr($i); ?>" value="yes" <?php echo ($require=='yes'? 'checked':'' );?>  class="text-center">
										</label>
									</td>
									<td>
									<?php
									if($i>1){
									?>
										<button class="btn btn-danger btn-xs" onclick="return iv_remove_field('<?php echo esc_attr($i); ?>');"><?php esc_html_e('Delete','wpmembership');?> </button>
									<?php
									}
									?>
									</td>
								</tr>	
								<?php
									$i++;
								}
							?>
						</tbody>
						<tfoot>
							<tr>
								<th> <?php  esc_html_e('Input Name','wpmembership')	;?> </th>
								<th> <?php  esc_html_e('Label','wpmembership')	;?> </th>
								<th> <?php  esc_html_e('Type','wpmembership')	;?> </th>
								<th> <?php  esc_html_e('Value[Dropdown,checkbox & Radio Button]','wpmembership')	;?> </th>
								<th> <?php  esc_html_e('User Role [Show on My Account/Profile]','wpmembership')	;?> </th>						
								<th> <?php  esc_html_e('Registration','wpmembership')	;?></th>
								<th> <?php  esc_html_e('My Account / Profile','wpmembership')	;?> </th>
								<th> <?php  esc_html_e('Require','wpmembership')	;?> </th>
								<th><?php  esc_html_e('Action','wpmembership')	;?></th>
							</tr>
						</tfoot>
					</table>
					
					<div id="custom_field_div">
					</div>
					<div class="col-xs-12">
						<button class="btn btn-warning " onclick="return iv_add_field();"><?php esc_html_e('Add More Field','wpmembership');?></button>
					</div>
				</div>
			</div>
		
				<div class="panel panel-success">
				<div class="panel-heading"><h4> <?php esc_html_e('My Account Menu','wpmembership');?></h4></div>
				<div class="panel-body">
					<div class="row ">
						<div class="col-sm-3 ">
							<h4><?php esc_html_e('Menu Title / Label','wpmembership');?> </h4>
						</div>
						<div class="col-sm-7">
							<h4><?php esc_html_e('Link','wpmembership');?></h4>
						</div>
						<div class="col-sm-2">
							<h4><?php esc_html_e('Action','wpmembership');?></h4>
						</div>
					</div>
					<?php
						$profile_page=get_option('_iv_membership_profile_page');
						$page_link= get_permalink( $profile_page);
					?>
					<div class="row ">
						<div class="col-sm-3 ">
							<?php esc_html_e('Membership Level','ivmembership');	 ?>
						</div>
						<div class="col-sm-7">
							<a href="<?php echo esc_url($page_link); ?>?&profile=level">
								<?php echo esc_url($page_link); ?>?&profile=level
							</a>
						</div>
						<div class="col-sm-2">
							<div class="checkbox ">
								<label><?php
									$account_menu_check='';
									if( get_option( '_iv_membership_mylevel' ) ) {
										$account_menu_check= get_option('_iv_membership_mylevel');
									}
								?>
								<input type="checkbox" name="mylevel" id="mylevel" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','wpmembership');?>
								</label>
							</div>
						</div>
					</div>
					<div class="row ">
						<div class="col-sm-3 ">
							<?php esc_html_e('Account Settings','ivmembership');?>
						</div>
						<div class="col-sm-7">
							<a href="<?php echo esc_url($page_link); ?>?&profile=setting">
								<?php echo esc_url($page_link); ?>?&profile=setting
							</a>
						</div>
						<div class="col-sm-2">
							<div class="checkbox ">
								<label><?php
									$account_menu_check='';
									if( get_option( '_iv_membership_menusetting' ) ) {
										$account_menu_check= get_option('_iv_membership_menusetting');
									}
								?>
								<input type="checkbox" name="menusetting" id="menusetting" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','wpmembership');?>
								</label>
							</div>
						</div>
					</div>
					<div class="row ">
						<div class="col-sm-3 ">
							<?php esc_html_e('Message','ivmembership');?>
						</div>
						<div class="col-sm-7">
							<a href="<?php echo esc_url($page_link); ?>?&profile=messageboard">
								<?php echo esc_url($page_link); ?>?&profile=messageboard
							</a>
						</div>
						<div class="col-sm-2">
							<div class="checkbox ">
								<label><?php
									$account_menu_check='';
									if( get_option( '_iv_membership_messageboard' ) ) {
										$account_menu_check= get_option('_iv_membership_messageboard');
									}
								?>
								<input type="checkbox" name="messageboard" id="messageboard" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','wpmembership');?>
								</label>
							</div>
						</div>
					</div>
					<div class="row ">
						<div class="col-sm-3 ">
							<?php esc_html_e('Image Gallery & Doc','ivmembership');?>
						</div>
						<div class="col-sm-7">
							<a href="<?php echo esc_url($page_link); ?>?&profile=images">
								<?php echo esc_url($page_link); ?>?&profile=images
							</a>
						</div>
						<div class="col-sm-2">
							<div class="checkbox ">
								<label><?php
									$account_menu_check='';
									if( get_option( '_iv_membership_menuimages' ) ) {
										$account_menu_check= get_option('_iv_membership_menuimages');
									}
								?>
								<input type="checkbox" name="menuimages" id="menuimages" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','wpmembership');?>
								</label>
							</div>
						</div>
					</div>
					<div class="row ">
						<div class="col-sm-3 ">
							<?php esc_html_e('Bookmark','ivmembership');?>
						</div>
						<div class="col-sm-7">
							<a href="<?php echo esc_url($page_link); ?>?&profile=bookmark">
								<?php echo esc_url($page_link); ?>?&profile=bookmark
							</a>
						</div>
						<div class="col-sm-2">
							<div class="checkbox ">
								<label><?php
									$account_menu_check='';
									if( get_option( '_iv_membership_bookmark' ) ) {
										$account_menu_check= get_option('_iv_membership_bookmark');
									}
								?>
								<input type="checkbox" name="bookmark" id="bookmark" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','wpmembership');?>
								</label>
							</div>
						</div>
					</div>
					<div class="row ">
						<div class="col-sm-3 ">
							<?php esc_html_e('All post','ivmembership');?>
						</div>
						<div class="col-sm-7">
							<a href="<?php echo esc_url($page_link); ?>?&profile=all-post">
								<?php echo esc_url($page_link); ?>?&profile=all-post
							</a>
						</div>
						<div class="col-sm-2">
							<div class="checkbox ">
								<label><?php
									$account_menu_check='';
									if( get_option( '_iv_membership_menuallpost' ) ) {
										$account_menu_check= get_option('_iv_membership_menuallpost');
									}
								?>
								<input type="checkbox" name="menuallpost" id="menuallpost" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> ><?php esc_html_e('Hide','wpmembership');?>
								</label>
							</div>
						</div>
					</div>
					<div class="row ">
						<div class="col-sm-3 ">
							<?php esc_html_e('New post','ivmembership');?>
						</div>
						<div class="col-sm-7">
							<a href="<?php echo esc_url($page_link); ?>?&profile=new-post">
								<?php echo esc_url($page_link); ?>?&profile=new-post
							</a>
						</div>
						<div class="col-sm-2">
							<div class="checkbox ">
								<label><?php
									$account_menu_check='';
									if( get_option( '_iv_membership_menunewpost' ) ) {
										$account_menu_check= get_option('_iv_membership_menunewpost');
									}
								?>
								<input type="checkbox" name="menunewpost" id="menunewpost" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','wpmembership');?>
								</label>
							</div>
						</div>
					</div>
					<div class="row ">
						<div class="col-sm-3 ">
							<?php esc_html_e('Woocommerce Billing Address','ivmembership');?>
						</div>
						<div class="col-sm-7">
							<a href="<?php echo esc_url($page_link); ?>?&profile=billing">
								<?php echo esc_url($page_link); ?>?&profile=billing
							</a>
						</div>
						<div class="col-sm-2">
							<div class="checkbox ">
								<label><?php
									$account_menu_check='';
									if( get_option( '_iv_membership_menubilling' ) ) {
										$account_menu_check= get_option('_iv_membership_menubilling');
									}
								?>
								<input type="checkbox" name="menubilling" id="menubilling" value="yes" <?php echo ($account_menu_check=='yes'? 'checked':'' ); ?> > <?php esc_html_e('Hide','wpmembership');?>
								</label>
							</div>
						</div>
					</div>
					<div id="custom_menu_div">
						<?php
							$old_custom_menu = array();
							if(get_option('iv_membership_profile_menu')){
								$old_custom_menu=get_option('iv_membership_profile_menu' );
							}
							$ii=1;
							if($old_custom_menu!=''){
								foreach ( $old_custom_menu as $field_key => $field_value ) {
								?>
								<div class="row form-group " id="menu_<?php echo esc_html($ii); ?>">
									<div class=" col-sm-3">
										<input type="text" class="form-control" name="menu_title[]" id="menu_title[]"  value="<?php echo esc_html($field_key); ?>" placeholder="<?php esc_html_e('Enter Menu Title','wpmembership'); ?>">
									</div>
									<div  class=" col-sm-7">
										<input type="text" class="form-control" name="menu_link[]" id="menu_link[]"  value="<?php echo esc_html($field_value); ?>" placeholder="<?php esc_html_e('Enter Menu Link','wpmembership'); ?>">
									</div>
									<div  class=" col-sm-2">
										<button class="btn btn-danger btn-xs" onclick="return iv_remove_menu('<?php echo esc_html($ii); ?>');"><?php esc_html_e('Delete','wpmembership');?></button>
									</div>
								</div>
								<?php
									$ii++;
								}
							}else{?>
							<div class="row form-group " id="menu_<?php echo esc_html($ii); ?>">
								<div class=" col-sm-3">
									<input type="text" class="form-control" name="menu_title[]" id="menu_title[]"   placeholder="<?php esc_html_e('Enter Menu Title', 'wpmembership'); ?> ">
								</div>
								<div  class=" col-sm-7">
									<input type="text" class="form-control" name="menu_link[]" id="menu_link[]"  placeholder="<?php esc_html_e('Enter Menu Link. Example  http://www.google.com', 'wpmembership'); ?>">
								</div>
								<div  class=" col-sm-2">
									<button class="btn btn-danger btn-xs" onclick="return iv_remove_menu('<?php echo esc_html($ii); ?>');"><?php esc_html_e('Delete','wpmembership');?></button>
								</div>
							</div>
							<?php
								$ii++;
							}
						?>
					</div>
					<div class="col-xs-12">
						<button class="btn btn-warning btn-xs" onclick="return iv_add_menu();"><?php esc_html_e('Add More','wpmembership');?></button>
					</div>
				</div>
			</div>
		
		</form>
		<div class="row">
			<div class="col-xs-12">
				<div align="center">
					<div id="success_message_profile"></div>
					<button class="btn btn-info btn-lg" onclick="return update_profile_fields();"><?php esc_html_e('Update','wpmembership');?> </button>
				</div>
				<p>&nbsp;</p>
			</div>
		</div>
		
		
	</div>
</div>
<?php
	wp_enqueue_script('wp-iv_membership-dashboard5', WP_iv_membership_URLPATH.'admin/files/js/profile-fields.js', array('jquery'), $ver = true, true );
	wp_localize_script('wp-iv_membership-dashboard5', 'profile_data', array( 			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.WP_iv_membership_URLPATH.'admin/files/images/loader.gif">',
	'redirecturl'	=>  WP_iv_membership_ADMINPATH.'admin.php?&page=wp-iv_membership-profile-fields',
	'adminnonce'=> wp_create_nonce("admin"),
	'pii'	=>$ii,
	'pi'	=> $i,
	"sProcessing"=>  esc_html__('Processing','wpmembership'),
	"sSearch"=>   esc_html__('Search','wpmembership'),
	"lengthMenu"=>   esc_html__('Display _MENU_ records per page','wpmembership'),
	"zeroRecords"=>  esc_html__('Nothing found - sorry','wpmembership'),
	"info"=>  esc_html__('Showing page _PAGE_ of _PAGES_','wpmembership'),
	"infoEmpty"=>   esc_html__('No records available','wpmembership'),
	"infoFiltered"=>  esc_html__('(filtered from _MAX_ total records)','wpmembership'),
	"sFirst"=> esc_html__('First','wpmembership'),
	"sLast"=>  esc_html__('Last','wpmembership'),
	"sNext"=>     esc_html__('Next','wpmembership'),
	"sPrevious"=>  esc_html__('Previous','jobboard'),
	) );
?>	