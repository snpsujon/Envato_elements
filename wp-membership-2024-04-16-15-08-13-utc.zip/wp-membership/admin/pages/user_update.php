<?php
	global $wpdb,$wp_roles;
	wp_enqueue_media();
	$user_id='1';
	if(isset($_GET['id'])){ $user_id=sanitize_text_field($_GET['id']);}
	$user = new WP_User( $user_id );
	$main_class = new WP_iv_membership;
	wp_enqueue_style('membership-my-account-css', WP_iv_membership_URLPATH . 'admin/files/css/my-account.css');
?>
<div class="bootstrap-wrapper">
	<div class=" dashboard-eplugin container-fluid" id="profile-account2">
		<div class="row">
			<div class="col-md-12"><h3 class=""><?php esc_html_e('User Settings: Edit','wpmembership'); ?> </h3>
			</div>
		</div>
		<div class="col-md-6 panel panel-info">
			<div class="panel-body">			
				<form role="form" id="user_form_iv" name="user_form_iv" onsubmit="return false;">
					<div class="form-group row">
						<label for="text" class="col-md-3 control-label"></label>
						<div id="iv-loading"></div>
					</div>
					<div class="form-group row">
						<label  class="control-label col-md-4"><?php esc_html_e('User Name','wpmembership'); ?></label>						
						<label class="control-label col-md-8"><?php echo esc_html($user->user_login); ?></label>						
					</div>
					<div class="form-group row">
						<label  class="control-label col-md-4"><?php esc_html_e('Email Address','wpmembership'); ?></label>					
						<label class="control-label col-md-8"><?php echo esc_html($user->user_email); ?></label>						
					</div>
					<div class="form-group row">
						<label  class="control-label col-md-4"><?php esc_html_e('Profile Image','wpmembership'); ?></label>					
						<label class="control-label col-md-8">
							<span id="profile_image_main">
						<?php
							$iv_profile_pic_url=get_user_meta($user_id, 'iv_profile_pic_thum',true);
							if($iv_profile_pic_url!=''){ ?>
								<img width="100px" src="<?php echo esc_url($iv_profile_pic_url); ?>">
							<?php
								}else{
								echo'	 <img width="100px" src="'. WP_iv_membership_URLPATH.'assets/images/Blank-Profile.jpg">';
							}
						?></span>
							<button type="button" onclick="edit_profile_image_admin('profile_image_main',<?php echo esc_html($user_id); ?>);"  class="btn green-haze btn-circle"><?php  esc_html_e('Change Image','wpmembership');?></button>
							
							</label>						
					</div>
					
					<?php
						$user_role= $user->roles[0];
					?>
					<div class="form-group row">
						<label for="text" class=" control-label col-md-4"><?php esc_html_e('User Role','wpmembership'); ?></label>
						<select name="user_role" id ="user_role" class="form-dropdown col-md-8">
								<?php
									foreach ( $wp_roles->roles as $key=>$value ){
										echo'<option value="'.esc_html($key).'"  '.($user_role==$key? " selected" : " ") .' >'.esc_html($key).'</option>';
									}
								?>
							</select>
						
					</div>
					<div class="form-group row">
						<label for="text" class="col-md-4 control-label"><?php esc_html_e('User Package', 'wpmembership'); ?></label>
					
							<?php
								$iv_membership_pack='iv_membership_pack';
								$sql=$wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_type = '%s'  and post_status='draft'", $iv_membership_pack ) ;
								$membership_pack = $wpdb->get_results($sql);
								$total_package=count($membership_pack);
								if($membership_pack>0){
									$i=0; $current_package_id=get_user_meta($user_id,'iv_membership_package_id',true);
									echo'<select name="package_sel2" id ="package_sel2" class=" form-dropdown col-md-8">';
									foreach ( $membership_pack as $row )
									{
										if($current_package_id==$row->ID){
											echo '<option value="'. esc_html($row->ID).'" selected>'.esc_html($row->post_title).esc_html__(' [User Current Package]','wpmembership').'</option>';
											}else{
											echo '<option value="'. esc_html($row->ID).'" >'. esc_html($row->post_title).'</option>';
										}
										$i++;
									}
									echo '</select>';
								}
							?>
						
					</div>
					<div class="form-group row">
						<label for="text" class="col-md-4 control-label"><?php esc_html_e('Payment Status','wpmembership'); ?></label>
						
							<?php
								$payment_status= get_user_meta($user_id, 'iv_membership_payment_status', true);
							?>
							<select name="payment_status" id ="payment_status" class="form-dropdown col-md-8">
								<option value="success" <?php echo ($payment_status == 'success' ? 'selected' : '') ?>><?php esc_html_e('Success','wpmembership'); ?></option>
								<option value="pending" <?php echo ($payment_status == 'pending' ? 'selected' : '') ?>><?php esc_html_e('Pending','wpmembership'); ?></option>
							</select>
						
					</div>
					<div class="form-group row">
						<label class="col-md-4 control-label"><?php esc_html_e('Expiry Date','wpmembership'); ?></label>						
							<?php
								$exp_date= get_user_meta($user_id, 'iv_membership_exprie_date', true);
							?>
						
						<input type="text"  name="exp_date"   id="exp_date" class="col-md-8 form-date"  value="<?php echo esc_html($exp_date); ?>">					
					</div>
					<?php
					$default_fields = array();
					$field_set=get_option('iv_membership_profile_fields' );
					if($field_set!=""){
						$default_fields=get_option('iv_membership_profile_fields' );
						}else{
						$default_fields['first_name']='First Name';
						$default_fields['last_name']='Last Name';
						$default_fields['phone']='Phone Number';
						$default_fields['mobile']='Mobile Number';
						$default_fields['address']='Address';
						$default_fields['city']='City';
						$default_fields['zipcode']='Zipcode';
						$default_fields['country-userprofile']='Country';
						$default_fields['job_title']='Job title';
						$default_fields['gender']='Gender';
						$default_fields['occupation']='Occupation';
						$default_fields['description']='About';
						$default_fields['web_site']='Website Url';
					}
					foreach ( $default_fields as $field_key => $field_value ) { 							
							 echo  $main_class->iv_membership_check_field_input_access($field_key, $field_value, 'myaccount', $user_id );
						}
					?>
					
					<input type="hidden"  name="user_id" id="user_id"   value="<?php echo esc_html($user_id); ?>" >
					<div class="row">
						<div class="col-md-12">
							<label for="" class="col-md-4 control-label"></label>
							<div class="col-md-8">
							<button class="btn btn-info " onclick="return update_user_setting();"><?php esc_html_e('Update User','wpmembership'); ?></button></div>
							<p>&nbsp;</p>
						</div>
					</div>
				
			
			</form>
			</div>
		</div>
	</div>
</div>