<?php
update_option('iv_membership_payment_gateway', 'paypal-express' ); 
update_option('iv_membership_payment_terms', 'yes' ); 
update_option('iv_membership_price-table', 'style-1' ); 
update_option('_iv_membership_api_currency', 'USD' );
update_option('iv_membership_payment_terms_text', ' I have read & accept the Terms & Conditions' ); 


?>
