<?php
update_option('iv_membership_signup-template', 'signup-style-1'); 
update_option('iv_membership_profile-template', 'style-1' ); 
update_option('iv_membership_profile-public', 'style-5' ); 
update_option('iv_membership_post_approved', 'yes' ); 
update_option('_iv_membership_hide_admin_bar', 'yes' ); 


?>
