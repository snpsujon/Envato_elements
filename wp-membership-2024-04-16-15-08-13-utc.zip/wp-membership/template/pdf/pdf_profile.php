<?php
	if(isset($_REQUEST['wpmembershippdfcv'])){ 
		global $html_pdf;
		global $current_user;
		$pdfpost_id='';$footer_html='';$header='';
		$current_lang="en";
		$lang=get_bloginfo("language");
		$language_array= explode("-",$lang);
		if(isset($language_array[0])){
			$current_lang=$language_array[0];
		}
		ob_clean();
		require ( WP_iv_membership_ABSPATH. 'inc/vendor/autoload.php');
		$user_id=1;
		if(isset($_REQUEST['wpmembershippdfcv'])){
			$author_name= sanitize_text_field($_REQUEST['wpmembershippdfcv']);
			$user = get_user_by( 'id', $author_name );
			if(isset($user->ID)){
				$user_id=$user->ID;
				$display_name=$user->display_name;
				$email=$user->user_email;
			}
		}	
	    $epfit_margin_left = '15';
		$epfit_margin_right ='15';
		$epfit_margin_top = '10';
		$epfit_margin_bottom = '30';
		$epfit_margin_header = '15';
		$mpdf_config = apply_filters('epfit_mpdf_config',[              
		'format'            => 'A4',
		'margin_left'       => $epfit_margin_left,
		'margin_right'      => $epfit_margin_right,
		'margin_top'        => $epfit_margin_top,
		'margin_bottom'     => $epfit_margin_bottom,
		'margin_header'     => $epfit_margin_header,  
			'fontdata' => [
				'frutiger' => [
					'R' => 'Roboto-Light.ttf',
					'I' => 'Roboto-LightItalic.ttf',
					'B' => 'Roboto-Bold.ttf',
					'BI' => 'Roboto-BoldItalic.ttf',
				]
			],
			'default_font' => 'Roboto'
		]);
		$mpdf = new \Mpdf\Mpdf( $mpdf_config );
		$footer_html='';
		if(isset($_REQUEST['wpmembershippdfcv'])){ $pdfpost_id=sanitize_text_field($_REQUEST['wpmembershippdfcv']); $postid=$pdfpost_id;}
		$postid=$pdfpost_id;	
		// Check access****************
		$has_access='yes';

		if($current_userID ==$user_for || $current_userID==$post_author_id){
			$has_access='yes';
		}
		if(isset($current_user->roles[0]) and $current_user->roles[0]=='administrator'){
			$has_access='yes';					
		}
		
		
		//***********End Access Check****************
		
	
		$full_name=$display_name;
		if(get_user_meta($user->ID,'first_name',true)!=''){
			$full_name=get_user_meta($user_id,'first_name',true).' '.get_user_meta($user_id,'last_name',true);
		}
		
		$footer_html=''.get_bloginfo();
		$iv_profile_pic_url=get_user_meta($postid, 'iv_profile_pic_thum',true);
		if($iv_profile_pic_url!=''){
				$iv_profile_pic_url= '<img height="150px" src="'.esc_url($iv_profile_pic_url).'">' ;		
		}
		$header = '	';
		$default_fields = array();
		$i=1;
		$address= get_user_meta($user_id,'address',true).' '.get_user_meta($user_id,'city',true).' '.get_user_meta($user_id,'zipcode',true).' '.get_user_meta($user_id,'country',true);
		
		$html_pdf=$html_pdf.'<body style="font-family: Helvetica; font-size: 11pt;"><table  class="tableContainer" style="border-collapse: collapse;width:100%;"   ><tr>		
			<td scope="row" style="text-align: left;width:50%"><h2>'. $full_name .'</h2> <br/> '.$email.'<br/>'.$address.'<br/> '. esc_html__('Phone','wpmembership').':'.get_user_meta($user_id,'phone',true).' </td>	
			<td scope="row" style="text-align: right;width:50%">'.$iv_profile_pic_url.'</td>	
			</tr></table>';
		$description=get_user_meta($postid,'description',true);
		$html_pdf=$html_pdf.'<table  class="tableContainer" style="border-collapse: collapse;width:100%;"   ><tr>		
			<td scope="row" style="text-align: left;width:100%"><h4>'. esc_html__('About','wpmembership').'</h4><hr>'.$description.'</td>
		</tr></table>';
		$html_pdf=$html_pdf.'<table  class="tableContainer" style="border-collapse: collapse;width:100%;margin-top:20px"   ><tr>		
			<td scope="row" style="text-align: left;width:100%"><h4>'. esc_html__('Personal Information','wpmembership').'</h4><hr></td>
		</tr>';
		
		$default_fields = array();
		$field_set=get_option('iv_membership_profile_fields' );
		if($field_set!=""){
			$default_fields=get_option('iv_membership_profile_fields' );
		}else{
			$default_fields['first_name']='First Name';
			$default_fields['last_name']='Last Name';
			$default_fields['phone']='Phone Number';											
			$default_fields['address']='Address';
			$default_fields['city']='City';
			$default_fields['zipcode']='Zipcode';
			$default_fields['country-userprofile']='Country';
			$default_fields['job_title']='Job title';
			$default_fields['gender']='Gender';
			$default_fields['occupation']='Occupation';
			$default_fields['description']='About';
			$default_fields['web_site']='Website Url';
		}
		$field_type_roles=  	get_option( 'iv_membership_field_type_roles' );		
		$myaccount_fields_array=  get_option( 'iv_membership_myaccount_fields' );	
		$user = new WP_User( $user_id );
		$i=1;
		foreach ( $default_fields as $field_key => $field_value ) {
			if(get_user_meta($user_id,$field_key,true)!=''){
				if($field_key!='description'){
					$role_access='no';
					if($myaccount_fields_array[$field_key]=='yes'){
						if(in_array('all',$field_type_roles[$field_key] )){
							$role_access='yes';
						}
						if(in_array('administrator',$field_type_roles[$field_key] )){
							$role_access='yes';
						}
						if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
							foreach ( $user->roles as $role )
								if(in_array($role,$field_type_roles[$field_key] )){
									$role_access='yes';
								}
								if('administrator'==$role){
									$role_access='yes';
								}
						}	
					}
					if($role_access=='yes'){	
					$html_pdf=$html_pdf.'<tr><td scope="row" style="text-align: left;width:100%;height:35px">'.esc_html($field_value).' : '.esc_html(get_user_meta($user_id,$field_key,true)).'</td></tr>';
					}
				}
			}
		}	
		
				
		$html_pdf=$html_pdf.'<div class="row">';			
		$gallery_ids=get_user_meta($user_id ,'image_gallery_ids',true);
		$gallery_ids_array = array_filter(explode(",", $gallery_ids));
		$i=1;
		foreach($gallery_ids_array as $slide){
			if($slide!=''){ 
			$html_pdf=$html_pdf.'				
					<img class="img-fluid rounded float" style="height:100px;  margin: 10px 10px 10px 0px;" src="'.wp_get_attachment_url( $slide ).'" >
					';					
				
			}
		}
	
		
		$html_pdf=$html_pdf.'</div>';			
		
		
		$html_pdf=$html_pdf.'</table></body>';
		$stylesheet = file_get_contents(WP_iv_membership_URLPATH . 'admin/files/css/pdf.css');		
		$mpdf->setFooter(''.$footer_html.', Page # {PAGENO}');	
		$mpdf->WriteHTML($html_pdf);
		$mpdf->Output();
		exit;
	}
?>