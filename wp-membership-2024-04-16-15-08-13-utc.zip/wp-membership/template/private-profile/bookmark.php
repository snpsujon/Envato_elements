<main class="main-content">
	<h4 class="lighter-heading border-btm"><?php  esc_html_e('Saved Profile ','wpmembership');?>  </h4>
	<section class="content-main-right list-jobs mb-30">
		<div class="list">
			<?php
				$favorites=get_user_meta(get_current_user_id(),'wpmembership_profilebookmark', true);	
				$favorites_a = array();
				$favorites_a = explode(",", $favorites);	
				$profile_page=get_option('_iv_membership_profile_public_page');
				$ids = array_filter($favorites_a);		
				if(sizeof($favorites_a)>0){
				?>
				<table id="user-bookmark" class="table tbl-epmplyer-bookmark" >
					<thead>
						<tr class="">
							<th><?php  esc_html_e('Title','wpmembership');?></th>
						</tr>
					</thead>
					<?php
						$i=0;
						foreach ($ids as $user_id){	 
							if((int)$user_id>0){
								$page_link= get_permalink( $profile_page).'?&id='.$user_id; 
								$user_data = get_user_by( 'ID', $user_id );
								$user_id=trim($user_id);
							?>
							<tr id="candidatebookmark_<?php echo esc_html(trim($user_id));?>" >
								<td class="d-md-table-cell">
									<div class="job-item bookmark">
										<div class="row align-items-center">
											<div class="col-md-2">
												<div class="img-job text-center circle">												
													<a href="<?php  echo esc_url($page_link); ?>">
														<?php
															$iv_profile_pic_url=get_user_meta($user_id, 'iv_profile_pic_thum',true);
															if($iv_profile_pic_url!=''){ ?>
															<img  src="<?php echo esc_url($iv_profile_pic_url); ?>">
															<?php
																}else{
																echo'<img src="'. WP_iv_membership_URLPATH.'assets/images/default-user.png">';
															}
														?>
													</a>
												</div>
											</div>
											<div class="col-md-10 job-info px-0">
												<div class="text px-0 text-left">
													<h4 class="title-job"><a href="<?php  echo esc_url($page_link); ?>">
														<?php echo (get_user_meta($user_id,'full_name',true)!=''? get_user_meta($user_id,'full_name',true) : $user_data->display_name ); ?>
													</a></h4>
												
													<div class="group-button">	
														<a class="btn btn-light btn-new" target="_blank" href="?&wpmembershippdfcv=<?php echo esc_attr(trim($user_id));?>"> <i class="far fa-file-alt"></i></a>
														<button class="btn btn-light btn-email" onclick="wpmembership_email_popup('<?php echo esc_attr(trim($user_id));?>')" ><i class="far fa-envelope"></i></button>
														<button class="btn btn-light btn-delete" onclick="candidate_bookmark_delete_myaccount('<?php echo esc_attr($user_id);?>','candidatebookmark')"><i class="far fa-trash-alt"></i></button>
													</div>
												</div>
											</div>
										</div>
									</div>
								</td>
							</tr>
							<?php
							}
						}
					?>
				</table>
				<?php
				}
			?>
		</div>
	</section>
</main>