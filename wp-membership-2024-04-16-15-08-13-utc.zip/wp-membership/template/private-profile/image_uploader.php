<form  name="profile_images_form" id="profile_images_form" action="#">
		<main class="profile-content">
	<h4 class="lighter-heading border-btm"><?php  esc_html_e('image Gallery & Doc','wpmembership');?>  </h4>
	<section class="content-main-right list-jobs mb-30">
<div class="row">

	<div class="col-md-6">
		<h4 class="lighter-heading "><?php echo esc_html_e('My Photos', 'wpmembership'); ?></h4>			
				<?php
					$package_id=get_user_meta($current_user->ID, 'ep_wpmembership_package_id',true);				
					$user_role= $current_user->roles[0];
					if(isset($current_user->roles[0]) and $current_user->roles[0]=='administrator'){
						$image_limit=999999;
					}
					$gallery_ids=get_user_meta($current_user->ID ,'image_gallery_ids',true);
					$gallery_ids_array = array_filter(explode(",", $gallery_ids));
				?>
				<input type="hidden" name="gallery_image_ids" id="gallery_image_ids" value="<?php echo esc_html($gallery_ids); ?>">
				<div class="row" id="gallery_image_div">
					<?php
						if(sizeof($gallery_ids_array)>0){
							foreach($gallery_ids_array as $slide){
							?>
							<div id="gallery_image_div<?php echo esc_html($slide);?>" class="col-md-4"><img  class="img-responsive"  src="<?php echo wp_get_attachment_url( $slide ); ?>"><button type="button" onclick="remove_gallery_image('gallery_image_div<?php echo esc_html($slide);?>', <?php echo esc_html($slide);?>);"  class="btn btn-xs btn-danger"><?php esc_html_e('X','wpmembership'); ?></button> </div>
							<?php
							}
						}
					?>
				</div>
				<div class="clearfix"><p></p></div>				
				<button type="button" onclick="edit_gallery_image('gallery_image_div');"  class="btn green-haze btn-circle btn-sm"><?php esc_html_e('Add Images','wpmembership'); ?></button>
			
	
	</div>
		<div class="col-md-6 ">
			<h4 class="lighter-heading "><?php echo esc_html_e('My Docs', 'wpmembership'); ?></h4>				
						<?php
							$gallery_ids=get_user_meta($current_user->ID ,'profile_doc_ids',true);
							$gallery_ids_array = array_filter(explode(",", $gallery_ids));
						?>
						<input type="hidden" name="gallery_doc_ids" id="gallery_doc_ids" value="<?php echo esc_html($gallery_ids); ?>">
						<div class="row" id="gallery_doc_div">
							<?php
								if(sizeof($gallery_ids_array)>0){
									foreach($gallery_ids_array as $slide){
										if(trim($slide)!=""){
										?>
										<div id="gallery_doc_div<?php echo esc_html($slide);?>" class="col-md-4">
										
												<a href="<?php echo wp_get_attachment_url( $slide );?>" target="_blank">
													<img src="<?php echo WP_iv_membership_URLPATH. "admin/files/images/pdf.png"; ?>">
												</a>												
												<div  class="col-md-12" style="font-size: 11px;">
													<?php
														$filename_only = basename( get_attached_file( $slide ) );
														echo esc_html($filename_only);
													?>
												</div>
												<div  class="col-md-2">
													<button type="button" onclick="remove_gallery_doc('gallery_doc_div<?php echo esc_html($slide);?>', <?php echo esc_html($slide);?>);"  class="btn btn-xs btn-danger">X</button>
												</div>
											</div>
										
										<?php
										}
									}
								}
							?>
						</div>
						<div class="clearfix"><p></p></div>		
					<button type="button" onclick="edit_gallery_doc('gallery_doc_div');"  class="btn green-haze btn-circle btn-sm"><?php esc_html_e('Add PDF Doc','wpmembership'); ?></button>
				
		</div>
</div>
	
<div class="row  margin-top-10">
<div class="col-md-12">
	<hr/>
	<div class=" pull-right mt-4" id="update_message_gallery"></div>
		<button type="button" onclick="update_profile_image_doc();"  class="btn green-haze"><?php  esc_html_e('Save Changes','wpmembership');?></button>	
</div>	

</div>	
<section>
	</main>
	</form>