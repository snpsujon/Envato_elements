<?php	
	$profile_url=get_permalink();
	global $current_user;
	$current_user = wp_get_current_user();
	$user = $current_user->ID;
	$message='';
	if(isset($_GET['delete_id']))  {
		$post_id=sanitize_text_field($_GET['delete_id']);
		$post_edit = get_post($post_id);
		if($post_edit->post_author==$current_user->ID){
			wp_delete_post($post_id);
			delete_post_meta($post_id,true);
			$message=esc_html__( 'Deleted Successfully', 'wpmembership' );
		}
	}
?>
<div class="profile-content">
	<div class="portlet light">
		<div class="portlet-title tabbable-line clearfix">
			<div class="caption caption-md">
					<h4 class="lighter-heading "><?php  esc_html_e('All Post','wpmembership');?></h4>
			</div>
		</div>
		<div class="portlet-body">
			<div class="tab-content">
				<div class="tab-pane active" id="tab_1_1">
					<?php
						$iv_post =get_option( '_iv_membership_profile_post');
						if($iv_post==''){
							$iv_post='post';
						}
						if($message!=''){
							echo  '<div class="alert alert-info alert-dismissable"><a class="panel-close close" data-dismiss="alert">x</a>'.esc_html($message).'.</div>';
						}
					?>
					
						<table id="user-bookmark" class="table table-striped ">
						<thead>
							<tr>
								<th><?php  esc_html_e('Title','wpmembership');?></th>
								<th><?php  esc_html_e('Status','wpmembership');?></th>
								<th><?php  esc_html_e('Actions','wpmembership');?></th>
							</tr>
							</thead>	
							<?php
								global $wpdb;
								$per_page=10;$row_strat=0;$row_end=$per_page;
								$current_page=0 ;
								if(isset($_REQUEST['cpage']) and $_REQUEST['cpage']!=1 ){
									$current_page=sanitize_text_field($_REQUEST['cpage']); $row_strat =($current_page-1)*$per_page;
									$row_end=$per_page;
								}
								$sql=$wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_type = '%s' and post_author='%s' and post_status IN ('publish','pending','draft' ) limit %d, %d", $iv_post ,$current_user->ID,$row_strat,$row_end);
								$authpr_post = $wpdb->get_results($sql);
								$total_post=count($authpr_post);
								if($total_post>0){
									$i=0;
									foreach ( $authpr_post as $row )
									{
									?>
									<tr>
										<td class="td65">
											<a class="profile-desc-link" href="<?php echo get_permalink($row->ID); ?>" class="plafont">
												<?php $feature_image = wp_get_attachment_image_src( get_post_thumbnail_id( $row->ID), 'thumbnail' );
													if($feature_image[0]!=""){ ?>
													<img title="profile image" class="plimg"  src="<?php  echo esc_html($feature_image[0]); ?>">
													<?php
													}
												?>
											&nbsp; <?php echo esc_html($row->post_title); ?></a></td>
											<td width="15%" class="plafont"><?php echo get_post_status( $row->ID ) ?></td>
											<td width="20%" >
												<?php
													$edit_post= $profile_url.'?&profile=post-edit&post-id='.esc_html($row->ID);
												?>
												<a href="<?php echo esc_html($edit_post); ?>" class="btn btn-xs green-haze" ><?php  esc_html_e('Edit','wpmembership');?></a>
												<a href="<?php echo esc_url($profile_url).'?&profile=all-post&delete_id='.esc_html($row->ID) ;?>"  onclick="return confirm('<?php  esc_html_e('Are you sure to delete this post?','wpmembership');?>');"  class="btn btn-xs btn-danger"><?php  esc_html_e('Delete','wpmembership');?>
												</a></td>
									</tr>
									<?php
									}
								}
							?>
						</table>
					
					
				</div>
			</div>
		</div>
	</div>
</div>