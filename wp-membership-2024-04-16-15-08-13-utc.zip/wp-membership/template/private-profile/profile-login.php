<?php
wp_enqueue_script('jquery');	
wp_enqueue_style('wp-iv_membership-style-11', WP_iv_membership_URLPATH . 'admin/files/css/iv-bootstrap.css');
wp_enqueue_style('wp-iv_membership-login', WP_iv_membership_URLPATH . 'admin/files/css/login.css');

?>
  <div id="login-2" class="bootstrap-wrapper">
   <div class="menu-toggler sidebar-toggler">
   </div>
   <div class="content">

    <form id="login_form" class="login-form" action="" method="post">
      <h3 class="form-title"><?php  esc_html_e('Sign In','wpmembership');?></h3>
      <div class="display-hide" id="error_message"> 
        
      </div>
      <div class="form-group">    
        <label class="control-label visible-ie8 visible-ie9"><?php  esc_html_e('Username','wpmembership');?></label>
        <input class="form-control form-control-solid placeholder-no-fix" type="text" autocomplete="off" placeholder="Username" name="username" id="username"/>
      </div>
      <div class="form-group">
        <label class="control-label visible-ie8 visible-ie9"><?php  esc_html_e('Password','wpmembership');?></label>
        <input class="form-control form-control-solid placeholder-no-fix" type="password" autocomplete="off" placeholder="Password" name="password" id="password"/>
      </div>
      <div class="form-actions row">
      <div class="col-md-4">
        <button type="button" class="btn btn-success uppercase pull-left" onclick="return chack_login();" ><?php  esc_html_e('Login','wpmembership');?></button>
      </div>
			
        <p class="pull-left margin-20 para col-md-8">
        <a href="javascript:;" class="forgot-link"><?php  esc_html_e('Forgot Password?','wpmembership');?></a>
        </p>
      </div>
      <?php
         if(has_action('oa_social_login')) {
        ?>
		 <div class="form-actions row">
			   <div class="col-md-4"> </div>
			   <div class="col-md-6"> <?php echo do_action('oa_social_login'); ?></div>			  
		</div>	
		<?php
		}
		?> 
    <div class="create-account">
          <p><?php
			$iv_redirect = get_option( '_iv_membership_price_table');
			$reg_page= get_permalink( $iv_redirect); 
			?>
            <a  href="<?php echo esc_url($reg_page);?>" id="register-btn" class="uppercase"><?php  esc_html_e('Create an account','wpmembership');?></a>
          </p>
        </div>    
    </form>   
    <form id="forget-password" name="forget-password" class="forget-form" action="" method="post" >
      <h3><?php  esc_html_e('Forget Password ?','wpmembership');?></h3>
	  <div id="forget_message"> 
		<p><?php  esc_html_e('Enter your e-mail address','wpmembership');?>         
      </p>
      </div>
      <div class="form-group">
        <input class="form-control form-control-solid placeholder-no-fix" type="text"  placeholder="Email" name="forget_email" id="forget_email"/>
      </div>
      <div class="">
        <button type="button" id="back-btn" class="btn btn-default uppercase margin-b-30"><?php  esc_html_e('Back','wpmembership');?></button>
        <button type="button" onclick="return forget_pass();"  class="btn btn-success uppercase pull-right margin-b-30"><?php  esc_html_e('Submit','wpmembership');?></button>
      </div>
    </form>
    </div>
    </div>
  <?php
	wp_enqueue_script('wp-iv_membership-my-account-login', WP_iv_membership_URLPATH.'admin/files/js/login.js');
	wp_localize_script('wp-iv_membership-my-account-login', 'ep_data', array( 			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.WP_iv_membership_URLPATH.'admin/files/images/loader.gif">',	
	'profilenonce'=> wp_create_nonce("settings"),
	'invalid'=> esc_html__('Invalid Username & Password','wpmembership'),
	'enteruser'=> esc_html__('Enter Username & Password','wpmembership'),
	'password_sent'=> esc_html__('Password Sent. Please check your email','wpmembership'),		
	) );
		?>