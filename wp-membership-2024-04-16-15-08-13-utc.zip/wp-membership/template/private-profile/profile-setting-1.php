<div class="profile-content">
	<div class="portlet row light">	
		<div class="col-md-12">
			<div class="portlet-title tabbable-line clearfix">
					<div class="caption caption-md">
						<h4 class="lighter-heading "><?php  esc_html_e('My Profile','wpmembership');?></h4>
						</div>
					<ul class="nav nav-tabs">
						<li class="active">
							<a href="#tab_1_1" data-toggle="tab"><?php   esc_html_e('Personal Info','wpmembership');?> </a>
						</li>
						
						<li>
							<a href="#tab_1_3" data-toggle="tab"><?php   esc_html_e('Password','wpmembership');?> </a>
						</li>
						<li>
							<a href="#tab_1_5" data-toggle="tab"><?php  esc_html_e('Social','wpmembership');?></a>
						</li>
						<li>
						<a href="#tab_1_4" data-toggle="tab"><?php  esc_html_e('Privacy Settings','wpmembership');?></a>
						</li>
						
					</ul>
					
			</div>
			
		</div>
		
		<div class="portlet-body col-md-12">
			<div class="tab-content">
				<div class="tab-pane active" id="tab_1_1">
					<form role="form" name="profile_setting_form" id="profile_setting_form" action="#">
						
						<?php
							$default_fields = array();
							$field_set=get_option('iv_membership_profile_fields' );
							if($field_set!=""){
								$default_fields=get_option('iv_membership_profile_fields' );
								}else{
								$default_fields['first_name']='First Name';
								$default_fields['last_name']='Last Name';
								$default_fields['phone']='Phone Number';								
								$default_fields['address']='Address';
								$default_fields['city']='City';
								$default_fields['zipcode']='Zipcode';
								$default_fields['country-userprofile']='Country';
								$default_fields['job_title']='Job title';
								$default_fields['gender']='Gender';
								$default_fields['occupation']='Occupation';
								$default_fields['description']='About';
								$default_fields['web_site']='Website Url';
							}	
							$field_type_roles=  	get_option( 'iv_membership_field_type_roles' );								
							$myaccount_fields_array=  get_option( 'iv_membership_myaccount_fields' );							
							$user = new WP_User( $current_user->ID );
							
							$i=1;
							foreach ( $default_fields as $field_key => $field_value ) { 		
								if(isset($myaccount_fields_array[$field_key])){
									if($myaccount_fields_array[$field_key]=='yes'){
										$role_access='no';
										if(in_array('all',$field_type_roles[$field_key] )){
											$role_access='yes';
										}
										if(in_array('administrator',$field_type_roles[$field_key] )){
											$role_access='yes';
										}
										if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
											foreach ( $user->roles as $role ){
												if(in_array($role,$field_type_roles[$field_key] )){
													$role_access='yes';
												}
												if('administrator'==$role){
													$role_access='yes';
												}
											}	
										}	
										if($role_access=='yes'){
											echo  $main_class->iv_membership_check_field_input_access($field_key, $field_value, 'myaccount', $current_user->ID );
										}
									}
								}else{
									echo  $main_class->iv_membership_check_field_input_access($field_key, $field_value, 'myaccount', $current_user->ID );
								}
							}
						?>
						
						
						<div class="margiv-top-10">
							<div class="" id="update_message"></div>
							<button type="button" onclick="update_profile_setting();"  class="btn green-haze"><?php  esc_html_e('Save Changes','wpmembership');?></button>
						</div>
					</form>
				</div>
				
					
				<div class="tab-pane" id="tab_1_3">
					<form action="" name="pass_word" id="pass_word">
						<div class="form-group">
							<label class="control-label"><?php  esc_html_e('Current Password','wpmembership');?></label>
							<input type="password" id="c_pass" name="c_pass" class="form-control"/>
						</div>
						<div class="form-group">
							<label class="control-label"><?php  esc_html_e('New Password','wpmembership');?></label>
							<input type="password" id="n_pass" name="n_pass" class="form-control"/>
						</div>
						<div class="form-group">
							<label class="control-label"><?php  esc_html_e('Re-type New Password','wpmembership');?></label>
							<input type="password" id="r_pass" name="r_pass" class="form-control"/>
						</div>
						<div class="margin-top-10">
							<div class="" id="update_message_pass"></div>
							<button type="button" onclick="iv_update_password();"  class="btn green-haze"><?php  esc_html_e('Change Password','wpmembership');?></button>							
						</div>
					</form>
				</div>
				<div class="tab-pane" id="tab_1_5">
					<form action="#" name="setting_fb" id="setting_fb">
						<div class="form-group">
							<label class="control-label"><?php  esc_html_e('FaceBook [Full URL]','wpmembership');?></label>
							<input type="text" name="facebook" id="facebook" value="<?php echo get_user_meta($current_user->ID,'facebook',true); ?>" class="form-control"/>
						</div>
						<div class="form-group">
							<label class="control-label"><?php  esc_html_e('Linkedin [Full URL]','wpmembership');?></label>
							<input type="text" name="linkedin" id="linkedin" value="<?php echo get_user_meta($current_user->ID,'linkedin',true); ?>" class="form-control"/>
						</div>
						<div class="form-group">
							<label class="control-label"><?php  esc_html_e('Twitter [Full URL]','wpmembership');?></label>
							<input type="text" name="twitter" id="twitter" value="<?php echo get_user_meta($current_user->ID,'twitter',true); ?>" class="form-control"/>
						</div>
						<div class="form-group">
							<label class="control-label"><?php  esc_html_e('instagram [Full URL]','wpmembership');?></label>
							<input type="text" name="instagram" id="instagram" value="<?php echo get_user_meta($current_user->ID,'instagram',true); ?>" class="form-control"/>
						</div>
						
						<div class="form-group">
							<label class="control-label"><?php  esc_html_e('Pinterest [Full URL]','wpmembership');?> </label>
							<input type="text" name="pinterest" id="pinterest" value="<?php echo get_user_meta($current_user->ID,'pinterest',true); ?>"  class="form-control"/>
						</div>
						<div class="form-group">
							<label class="control-label"><?php  esc_html_e('Youtube [Full URL]','wpmembership');?> </label>
							<input type="text" name="youtube" id="youtube" value="<?php echo get_user_meta($current_user->ID,'youtube',true); ?>"  class="form-control"/>
						</div>
						<div class="margin-top-10">
							<div class="" id="update_message_fb"></div>
							<button type="button" onclick="iv_update_fb();"  class="btn green-haze"><?php  esc_html_e('Save Changes','wpmembership');?></button>
					
						</div>
					</form>
				</div>
				<div class="tab-pane" id="tab_1_4">
					<form action="#" name="setting_hide_form" id="setting_hide_form">
						<div class="table-responsive">
							<table class="table table-light table-hover">
								<tr>
									<td class="tdfont">
										<?php  esc_html_e('Hide Email Address From Profile ','wpmembership');?>
									</td>
									<td>
										<label class="uniform-inline">
										<input type="checkbox" id="email_hide" name="email_hide"  value="yes" <?php echo( get_user_meta($current_user->ID,'hide_email',true)=='yes'? 'checked':''); ?>/> <?php  esc_html_e('Yes','wpmembership');?> </label>
									</td>
								</tr>
								<tr>
									<td class="tdfont">
										<?php  esc_html_e('Hide Phone Number From Profile','wpmembership');?>
									</td>
									<td>
										<label class="uniform-inline">
										<input type="checkbox" id="phone_hide" name="phone_hide" value="yes" <?php echo( get_user_meta($current_user->ID,'hide_phone',true)=='yes'? 'checked':''); ?>  /> <?php  esc_html_e('Yes','wpmembership');?> </label>
									</td>
								</tr>
								<tr>
									<td class="tdfont">
										<?php  esc_html_e('Hide Contact Button From Profile','wpmembership');?>
									</td>
									<td>
										<label class="uniform-inline">
										<input type="checkbox" id="contact_button_hide" name="contact_button_hide" value="yes"  <?php echo( get_user_meta($current_user->ID,'contact_button_hide',true)=='yes'? 'checked':''); ?> /> <?php  esc_html_e('Yes','wpmembership');?> </label>
									</td>
								</tr>
								<tr>
									<td class="tdfont">
										<?php  esc_html_e('Hide PDF Button From Profile','wpmembership');?>
									</td>
									<td>
										<label class="uniform-inline">
										<input type="checkbox" id="pdf_button_hide" name="pdf_button_hide" value="yes"  <?php echo( get_user_meta($current_user->ID,'pdf_button_hide',true)=='yes'? 'checked':''); ?> /> <?php  esc_html_e('Yes','wpmembership');?> </label>
									</td>
								</tr>
							</table>
						</div>
					
						<div class="margin-top-10">
						  <div class="" id="update_message_hide"></div>
							<button type="button" onclick="iv_update_hide_setting();"  class="btn green-haze"><?php  esc_html_e('Save Changes','wpmembership');?></button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

