<?php
	wp_enqueue_script('jquery');
	wp_enqueue_script('jquery-ui-core');
	wp_enqueue_script('jquery-ui-datepicker'); 
	wp_enqueue_style('wp-wpmembership-public-111', WP_iv_membership_URLPATH .'admin/files/css/iv-bootstrap-4.css');
	wp_enqueue_style('membership-my-account-css', WP_iv_membership_URLPATH . 'admin/files/css/my-account.css');
	wp_enqueue_script('bootstrap', WP_iv_membership_URLPATH . 'admin/files/js/bootstrap.min.js');
	wp_enqueue_style('all', WP_iv_membership_URLPATH . 'admin/files/css/all.min.css');
	wp_enqueue_style('main-css', WP_iv_membership_URLPATH . 'admin/files/css/main.css');
	wp_enqueue_style('wpmembership-my-menu-css', WP_iv_membership_URLPATH . 'admin/files/css/cssmenu.css');
	wp_enqueue_style('jquery.dataTables', WP_iv_membership_URLPATH . 'admin/files/css/jquery.dataTables.css');
	wp_enqueue_script('jquery.dataTables', WP_iv_membership_URLPATH . 'admin/files/js/jquery.dataTables.js');	
	wp_enqueue_style('colorbox', WP_iv_membership_URLPATH . 'admin/files/css/colorbox.css');
	wp_enqueue_script('colorbox', WP_iv_membership_URLPATH . 'admin/files/js/jquery.colorbox-min.js');
	wp_enqueue_style('epdirpro-stylejqueryUI-666', WP_iv_membership_URLPATH . 'admin/files/css/jquery-ui.css');
	wp_enqueue_style('datetimepicker', WP_iv_membership_URLPATH . 'admin/files/css/jquery.datetimepicker.css');
	wp_enqueue_media();
	global $current_user;
	$main_class = new WP_iv_membership;
	$crole='';
	$user = new WP_User( $current_user->ID );
	if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
		foreach ( $user->roles as $role ){
			$crole= ucfirst($role);
			break;
		}
	}
	if(strtoupper($crole)!=strtoupper('administrator')){
		include(WP_iv_membership_template.'/private-profile/check_status.php');
	}
	
	$current_user = wp_get_current_user();
?>
<div id="profile-account2" class="bootstrap-wrapper around-separetor">
	<div class="row margin-top-10">
		<div class="col-md-4 col-sm-4 col-xs-12">
			<div class="profile-sidebar">
				<div class="portlet portlet0 light profile-sidebar-portlet">
					<div class=" p-2 text-center" id="profile_image_main">
						<?php
							$iv_profile_pic_url=get_user_meta($current_user->ID, 'iv_profile_pic_thum',true);
							if($iv_profile_pic_url!=''){ ?>
							<img class="img-thumbnail" src="<?php echo esc_url($iv_profile_pic_url); ?>">
							<?php
								}else{
								echo'	 <img src="'. WP_iv_membership_URLPATH.'assets/images/Blank-Profile.jpg">';
							}
						?>
					</div>
					<div class="profile-usertitle">
						<div class="profile-usertitle-name">
							<?php
								$name_display=get_user_meta($current_user->ID,'first_name',true).' '.get_user_meta($current_user->ID,'last_name',true);
							echo (trim($name_display)!=""? $name_display : $current_user->display_name );?>
						</div>
						<div class="profile-usertitle-job">
							<?php echo get_user_meta($current_user->ID,'occupation',true); ?>
						</div>
					</div>
					<div class="profile-userbuttons">
						<button type="button" onclick="edit_profile_image('profile_image_main');"  class="btn green-haze btn-circle"><?php  esc_html_e('Change Image','wpmembership');?></button>
						<?php
						$profile_page=get_option('_iv_membership_profile_public_page');
						$page_link= get_permalink( $profile_page).'?&id='.$current_user->ID; 
						?>
						<a href="<?php echo esc_url($page_link); ?>"   class="btn green-haze btn-circle"><?php  esc_html_e('Profile','wpmembership');?></a>
					</div>
					<div class="profile-usermenu">
					<div id='cssmenu'>
						<?php
							$active='setting';
							if(isset($_GET['profile']) AND $_GET['profile']=='setting' ){
								$active='setting';
							}
							if(isset($_GET['profile']) AND $_GET['profile']=='level' ){
								$active='level';
							}
							if(isset($_GET['profile']) AND $_GET['profile']=='all-post' ){
								$active='all-post';
							}
							if(isset($_GET['profile']) AND $_GET['profile']=='new-post' ){
								$active='new-post';
							}
							if(isset($_GET['profile']) AND $_GET['profile']=='billing' ){
								$active='billing';
							}
							if(isset($_GET['profile']) AND $_GET['profile']=='billing' ){
								$active='billing';
							}
							if(isset($_GET['profile']) AND $_GET['profile']=='messageboard' ){
								$active='messageboard';
							}
							if(isset($_GET['profile']) AND $_GET['profile']=='bookmark' ){
								$active='bookmark';
							}
							if(isset($_GET['profile']) AND $_GET['profile']=='images' ){
								$active='images';
							}
							$iv_post = get_option( '_iv_membership_profile_post');
							if($iv_post!=''){
								$post_type=  $iv_post;
								}else{
								$post_type=  'Post';
							}
						?>
						<ul class="">
							<?php
								$account_menu_check= '';
								if( get_option( '_iv_membership_mylevel' ) ) {
									$account_menu_check= get_option('_iv_membership_mylevel');
								}
								if($account_menu_check!='yes'){
								?>
								<li class="<?php echo ($active=='level'? 'active':''); ?> ">
									<a href="<?php echo get_permalink(); ?>?&profile=level">
                    <i class="fas fa-user-lock"></i>
									<?php  esc_html_e('Membership','wpmembership');?> </a>
								</li>
								<?php
								}
							?>
							<?php
								$account_menu_check= '';
								if( get_option( '_iv_membership_menusetting' ) ) {
									$account_menu_check= get_option('_iv_membership_menusetting');
								}
								if($account_menu_check!='yes'){
								?>
								<li class="<?php echo ($active=='setting'? 'active':''); ?> ">
									<a href="<?php echo get_permalink(); ?>?&profile=setting">
									<i class="fas fa-cog"></i>
									<?php  esc_html_e('Settings ','wpmembership');?></a>
								</li>
								<?php
								}
							?>
							<?php
								$account_menu_check= '';
								if( get_option( '_iv_membership_menuimages' ) ) {
									$account_menu_check= get_option('_iv_membership_menuimages');
								}
								if($account_menu_check!='yes'){
								?>
								<li class="<?php echo ($active=='images'? 'active':''); ?> ">
									<a href="<?php echo get_permalink(); ?>?&profile=images">
									<i class="fas fa-cog"></i>
									<?php  esc_html_e('Images/ Doc ','wpmembership');?></a>
								</li>
								<?php
								}
							?>
							<?php
								$account_menu_check= '';
								if( get_option( '_iv_membership_messageboard' ) ) {
									$account_menu_check= get_option('_iv_membership_messageboard');
								}
								if($account_menu_check!='yes'){
								?>
								<li class="<?php echo ($active=='messageboard'? 'active':''); ?> ">
									<a href="<?php echo get_permalink(); ?>?&profile=messageboard">
										<i class="far fa-envelope"></i>
									<?php  esc_html_e('Message','wpmembership');?></a>
								</li>
							
							<?php
								}
							?>
							<?php
								$account_menu_check= '';
								if( get_option( '_iv_membership_bookmark' ) ) {
									$account_menu_check= get_option('_iv_membership_bookmark');
								}
								if($account_menu_check!='yes'){
								?>
								<li class="<?php echo ($active=='bookmark'? 'active':''); ?> ">
									<a href="<?php echo get_permalink(); ?>?&profile=bookmark">
										<i class="fas fa-user"></i>
									<?php  esc_html_e('Bookmark','wpmembership');?></a>
								</li>	
							<?php
								}
							?>
							<?php
								$account_menu_check= '';
								if( get_option( '_iv_membership_menuallpost' ) ) {
									$account_menu_check= get_option('_iv_membership_menuallpost');
								}
								if($account_menu_check!='yes'){
								?>
								<li class="<?php echo ($active=='all-post'? 'active':''); ?> ">
									<a href="<?php echo get_permalink(); ?>?&profile=all-post">
                    <i class="fas fa-list-ul"></i>
									<?php  esc_html_e('All','wpmembership');?> <?php echo esc_html($post_type);?> </a>
								</li>
								<?php
								}
							?>
							<?php
								$account_menu_check= '';
								if( get_option( '_iv_membership_menunewpost' ) ) {
									$account_menu_check= get_option('_iv_membership_menunewpost');
								}
								if($account_menu_check!='yes'){
								?>
								<li class="<?php echo ($active=='new-post'? 'active':''); ?> ">
									<a href="<?php echo get_permalink(); ?>?&profile=new-post">
                    <i class="fas fa-plus-square"></i>
									<?php  esc_html_e('New','wpmembership');?> <?php echo esc_html($post_type);?> </a>
								</li>
								<?php
								}
							?>
							
							
							<?php
								$account_menu_check= '';
								if( get_option( '_iv_membership_menubilling' ) ) {
									$account_menu_check= get_option('_iv_membership_menubilling');
								}
								if($account_menu_check!='yes'){
								?>
								<li class="<?php echo ($active=='billing'? 'active':''); ?> ">
									<a href="<?php echo get_permalink(); ?>?&profile=billing">
										<i class="fas fa-address-card"></i>
									<?php  esc_html_e('Billing Address','wpmembership');?>  </a>
								</li>
								<?php
								}
							?>
							<?php     $old_custom_menu = array();
								if(get_option('iv_membership_profile_menu')){
									$old_custom_menu=get_option('iv_membership_profile_menu' );
								}
								$ii=1;
								if($old_custom_menu!=''){
									foreach ( $old_custom_menu as $field_key => $field_value ) { ?>
									<li class=" ">
										<a href="<?php echo esc_html($field_value); ?>">
											<i class="fas fa-cog"></i>
										<?php echo esc_html($field_key);?> </a>
									</li>
									<?php
									}
								}
							?>
							<li class="<?php echo ($active=='log-out'? 'active':''); ?> ">
								<a href="<?php echo wp_logout_url( home_url() ); ?>" >
									<i class="fas fa-sign-out-alt"></i>
									<?php  esc_html_e('Sign out','wpmembership');?>
								</a>
							</li>
						</ul>
					</div>
					</div>
				</div>

			</div>
		</div>
		<?php ?>
		<div class="col-md-8 col-sm-8 col-xs-12">
		  <?php
				if(isset($_GET['profile']) AND $_GET['profile']=='all-post' ){
						include(  WP_iv_membership_template. 'private-profile/profile-all-post-1.php');
					}elseif(isset($_GET['profile']) AND $_GET['profile']=='new-post' ){
						include( WP_iv_membership_template. 'private-profile/profile-new-post-1.php');
					}elseif(isset($_GET['profile']) AND $_GET['profile']=='level' ){
						include(  WP_iv_membership_template. 'private-profile/profile-level-1.php');
					}elseif(isset($_GET['profile']) AND $_GET['profile']=='post-edit' ){
						include(  WP_iv_membership_template. 'private-profile/profile-edit-post-1.php');
					}elseif(isset($_GET['profile']) AND $_GET['profile']=='billing' ){
						include(  WP_iv_membership_template. 'private-profile/profile-billing-address.php');
					}elseif(isset($_GET['profile']) AND $_GET['profile']=='messageboard' ){
						include(  WP_iv_membership_template. 'private-profile/messageboard.php');
					}elseif(isset($_GET['profile']) AND $_GET['profile']=='bookmark' ){
						include(  WP_iv_membership_template. 'private-profile/bookmark.php');
					}elseif(isset($_GET['profile']) AND $_GET['profile']=='images' ){
						include(  WP_iv_membership_template. 'private-profile/image_uploader.php');					
					}else{
					include(  WP_iv_membership_template. 'private-profile/profile-setting-1.php');
				}
			?>
		</div> 
	</div>
</div>
<?php
	$currencyCode= get_option('_iv_membership_api_currency');
	$iv_gateway = get_option('iv_membership_payment_gateway');
	wp_enqueue_script('wp-iv_membership-epmember', WP_iv_membership_URLPATH.'admin/files/js/my-account.js');
	wp_localize_script('wp-iv_membership-epmember', 'ep_data', array( 			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.WP_iv_membership_URLPATH.'admin/files/images/loader.gif">',
	'pdf_image_url'	=> WP_iv_membership_URLPATH.'admin/files/images/pdf.png',	
	'profilenonce'=> wp_create_nonce("settings"),
	'signup'=> wp_create_nonce("signup"),
	'edit'=> esc_html__( 'Edit','wpmembership'),
	'remove'=> esc_html__( 'Remove','wpmembership'),
	'dirwpnonce'=> wp_create_nonce("myaccount"),
	'set_image'=> esc_html__( 'Set Image','wpmembership'),
	'confirmmessage'=> esc_html__( 'Are you sure to cancel this Membership?','wpmembership'),
	'currencyCode'=> $currencyCode,
	'iv_gateway'=> $iv_gateway,
	'all_postpage'=> get_permalink().'?&profile=all-post',
	"sProcessing"=>  esc_html__('Processing','jobboard'),
	"sSearch"=>   esc_html__('Search','jobboard'),
	"lengthMenu"=>   esc_html__('Display _MENU_ records per page','jobboard'),
	"zeroRecords"=>  esc_html__('Nothing found - sorry','jobboard'),
	"info"=>  esc_html__('Showing page _PAGE_ of _PAGES_','jobboard'),
	"infoEmpty"=>   esc_html__('No records available','jobboard'),
	"infoFiltered"=>  esc_html__('(filtered from _MAX_ total records)','jobboard'),
	"sFirst"=> esc_html__('First','jobboard'),
	"sLast"=>  esc_html__('Last','jobboard'),
	"sNext"=>     esc_html__('Next','jobboard'),
	"sPrevious"=>  esc_html__('Previous','jobboard'),
	) );
	wp_enqueue_script('epmyaccount-script-27', WP_iv_membership_URLPATH . 'admin/files/js/public-profile.js');
	wp_localize_script('epmyaccount-script-27', 'wpmembership1', array(
	'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.WP_iv_membership_URLPATH.'admin/files/images/loader.gif">',
	'wp_iv_directories_URLPATH'		=> WP_iv_membership_URLPATH,
	'current_user_id'	=>get_current_user_id(),
	'dirwpnonce'=> wp_create_nonce("myaccount"),
	"Please_login"=>  esc_html__('Please Login','wpmembership'), 
	'Add_to_Boobmark'=>esc_html__('Add to Boobmark', 'wpmembership' ),
	'Added_to_Boobmark'=>esc_html__('Added to Boobmark', 'wpmembership' ),	
	
	) );
	wp_enqueue_script('wpmembership_message', WP_iv_membership_URLPATH . 'admin/files/js/user-message.js');
	wp_localize_script('wpmembership_message', 'wpmembership_data_message', array(
		'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
		'loading_image'		=> '<img src="'.WP_iv_membership_URLPATH.'admin/files/images/loader.gif">',		
		'Please_put_your_message'=>esc_html__('Please put your name,email & message', 'wpmembership' ),
		'contact'=> wp_create_nonce("contact"),
		'listing'=> wp_create_nonce("listing"),
		) );
	
	
?>
