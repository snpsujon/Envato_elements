<?php
	wp_enqueue_script("jquery");	
	wp_enqueue_style('wp-wpmembership-public-111', WP_iv_membership_URLPATH .'admin/files/css/iv-bootstrap-4.css');
	wp_enqueue_style('wp-wpmembership-piblic-13', WP_iv_membership_URLPATH . 'admin/files/css/profile-public.css');
	wp_enqueue_style('all-awesome', WP_iv_membership_URLPATH . 'admin/files/css/all.min.css');
	wp_enqueue_style('colorbox', WP_iv_membership_URLPATH . 'admin/files/css/colorbox.css');
	wp_enqueue_script('colorbox', WP_iv_membership_URLPATH . 'admin/files/js/jquery.colorbox-min.js');
	/**************************** css resources from qdesk ********************************************/
	wp_enqueue_style('main-css', WP_iv_membership_URLPATH . 'admin/files/css/main.css');
	wp_enqueue_style('jquery.fancybox', WP_iv_membership_URLPATH . 'admin/files/css/jquery.fancybox.css');
	wp_enqueue_script('jquery.fancybox',WP_iv_membership_URLPATH . 'admin/files/js/jquery.fancybox.js');
	/***************************************************************************************
		***************/
	$display_name='';
	$email='';
	$current_page_permalink='';
	$user_id=1;
	global $current_user;
	
	if(isset($_REQUEST['id'])){ 
		$author_name= sanitize_text_field($_REQUEST['id']);
		$user = get_user_by( 'ID', $author_name );
		if(isset($user->ID)){
			$user_id=$user->ID;
			$display_name=$user->display_name;
			$email=$user->user_email;
		}
	}else{
		 
		$user_id=$current_user->ID;
		$display_name=$current_user->display_name;
		$email=$current_user->user_email;
		$author_name= $current_user->ID;
		if($user_id==0){
			$user_id=1;
		}
	}
?>
<div class="bootstrap-wrapper wrapper" id="">
	<input type="hidden" id="profileID" value="<?php echo esc_attr($user_id); ?>">
	<main class=" pt-1">
        <div class="primary-page">
			<div class="container">
				<div class="item-detail-special contentshowep">
					<div class="col-md-2 ">
						<?php
							$iv_profile_pic_url=get_user_meta($user_id, 'iv_profile_pic_thum',true);
							if($iv_profile_pic_url!=''){ ?>
							<img  src="<?php echo esc_url($iv_profile_pic_url); ?>">
							<?php
								}else{
								echo'<img src="'. WP_iv_membership_URLPATH.'assets/images/default-user.png">';
							}
						?>
					</div>
					<div class="col-md-7">
						<div class="row align-items-lg-center">
							<div class="col-lg-7 col-xl-8 ">
								<h2 class="title-detail">
									<?php 
												$full_name=$display_name;
												if(get_user_meta($user->ID,'first_name',true)!=''){
													$full_name=get_user_meta($user_id,'first_name',true).' '.get_user_meta($user_id,'last_name',true);
												}
										echo esc_html($full_name); ?></h2>
								
							<div class="meta-job">
								<p>
								
									<?php
									if(get_user_meta($user_id,'hide_phone',true)!='yes'){
										if(get_user_meta($user_id,'phone',true)!=''){
										?>
										<span class="phone"><i class="fa fa-mobile-alt"></i><?php echo esc_html(get_user_meta($user_id,'phone',true)); ?></span>
										<?php
										}
									}	
									?>
									
									<?php
									if(get_user_meta($user_id,'hide_email',true)!='yes'){
										if(!empty($email)){
										?>
										<span class="mail"><i class="far fa-envelope"></i><?php echo esc_html($email); ?></span>
										<?php
										}
									}	
									?>
								</p>
							</div>
						</div>
						
					</div>
				</div>
				<div class="col-md-3">
					<div class="btn-feature">
					<?php
					if(get_user_meta($user_id,'pdf_button_hide',true)!='yes'){
						?>
					<a class="btn btn-light-green" href="<?php echo get_permalink($current_page_permalink);?>?&wpmembershippdfcv=<?php echo esc_attr($user_id);?>" target="_blank"><i class="fas fa-download"></i> <?php esc_html_e('PDF', 'wpmembership'); ?></a>
					<?php
					}
					?>
						<?php						
							$current_ID = get_current_user_id();
							$favourites='no';
							if($current_ID>0){
								$my_favorite = get_post_meta($user_id,'wpmembership_profilebookmark',true);								
								$all_users = explode(",", $my_favorite);
								if (in_array($current_ID, $all_users)) {
									$favourites='yes';
								}
							}
							$added_to_Boobmark=esc_html__('Added to Boobmark', 'wpmembership');
							$add_to_Boobmark=esc_html__('Add to Boobmark', 'wpmembership');
						?>
						<button id="candidatebookmark" class="btn <?php echo ($favourites=='yes'?'btn-added-favourites ':'btn-light btn-add-favourites' ); ?>"  title="<?php echo ($favourites=='yes'? $added_to_Boobmark: $add_to_Boobmark ); ?>" ><i class="far fa-star"></i></button>
						
						
					</div> 
				</div>                   
			</div>
			
			<div class="row">
				<div class="col-lg-8">
					<div class="content-main-right single-detail contentshowep">
						<div class="box-description">
							<h3><?php esc_html_e('About', 'wpmembership'); ?></h3>
							<?php 		$content= get_user_meta($user_id,'description',true);
								$content = apply_filters('the_content', $content);
								$content = str_replace(']]>', ']]&gt;', $content);
								echo wpautop($content);
							?>
						</div>
						<?php
						$wpmembership_dir_images=get_option('wpmembership_dir_images');	
						if($wpmembership_dir_images==""){$wpmembership_dir_images='yes';}
						if($wpmembership_dir_images=="yes"){
						?>
						<div class="row">
							<?php
								$gallery_ids=get_user_meta($user_id ,'image_gallery_ids',true);
								$gallery_ids_array = array_filter(explode(",", $gallery_ids));
								$i=1;
								foreach($gallery_ids_array as $slide){
									if($slide!=''){ ?>
									<div class=" p-2  col-md-3">
										<a data-fancybox="gallery" href="<?php echo wp_get_attachment_url( $slide ); ?>">
											<img class="img-fluid rounded float" src="<?php echo wp_get_attachment_url( $slide ); ?>" >
										</a>
									</div>
									<?php
										$i++;
									}
								}
								
							?>
						</div>
						<?php
						}
					?>	
					<div class="row mt-3">						
						
						<?php
							
							$doc_ids=get_user_meta($user_id ,'profile_doc_ids',true);
							$doc_ids_array = array_filter(explode(",", $doc_ids));
							$i=1;
							if(sizeof($doc_ids_array)>0){
								foreach($doc_ids_array as $doc){
									if(trim($doc)!=""){									
										?>
										<div  class="col-md-3 col-xs-12">
											<div class="panel panel-default">
												<div class="panel-heading"><?php
													$filename_only = basename( get_attached_file( $doc ) );
												?></div>
												<div class="panel-body text-center"><a href="<?php echo wp_get_attachment_url( $doc );?>" target="_blank">
													<img src="<?php echo WP_iv_membership_URLPATH. "admin/files/images/pdf.png"; ?>">
												<span style="font-size:11px"><?php echo esc_html($filename_only); ?></span>
												</a>
												</div>
											</div>
										</div>
										<?php
										
									}
									$i++;
								}
							}
						?>
						</div>					
					</div>
							<div class="simillar-jobs">							
							<div class="content-main-right list-jobs contentshowep">							
								<div class="list ">
								<h3 class="p-4"><?php esc_html_e('Posts', 'wpmembership'); ?></h3>
								<?php
							
								$args = array(
									'post_type' => 'post', // enter your custom post type
									'paged' => '1',
									'author'=> $user_id , 
									'post_status' => 'publish',	
									'posts_per_page'=> '10',  // overrides posts per page in theme settings
								);
								$open_positions = new WP_Query( $args );
								 if ( $open_positions->have_posts() ) :
								 while ( $open_positions->have_posts() ) : $open_positions->the_post();
												$postid = get_the_ID();
									?>			
									<div class="job-item">
										<div class="row align-items-center">
											<div class="col-md-9 col-lg-8 col-xl-9">
												<div class="text">
													<h3 class="title-job"><a href="<?php echo get_the_permalink($postid); ?>"><?php echo get_the_title($postid); ?></a></h3>
													<div class="date-job">
														<p><?php esc_html_e('Posted ', 'wpmembership'); ?> <?php echo get_the_date('M d, Y', $postid); ?></p>
													</div>
													
												</div>
											</div>
											
										</div>
									</div>
										
									
								<?php	
									endwhile;
								endif;
								?>									
								</div>
							</div>
						</div>
						
					
				</div>
				<div class="col-lg-4">
					<div class="sidebar-right contentshowep">
						<div class="sidebar-right-group">
							<div class="job-detail-summary">
								<h3 class="title-block"><?php esc_html_e('Personal Information', 'wpmembership'); ?></h3>
								<ul>
								<?php
										$default_fields = array();
										$field_set=get_option('iv_membership_profile_fields' );
										if($field_set!=""){
											$default_fields=get_option('iv_membership_profile_fields' );
											}else{
											$default_fields['first_name']='First Name';
											$default_fields['last_name']='Last Name';
											$default_fields['phone']='Phone Number';											
											$default_fields['address']='Address';
											$default_fields['city']='City';
											$default_fields['zipcode']='Zipcode';
											$default_fields['country-userprofile']='Country';
											$default_fields['job_title']='Job title';
											$default_fields['gender']='Gender';
											$default_fields['occupation']='Occupation';
											$default_fields['description']='About';
											$default_fields['web_site']='Website Url';
										}
										$i=1;
										$field_type_roles=  	get_option( 'iv_membership_field_type_roles' );		
										$myaccount_fields_array=  get_option( 'iv_membership_myaccount_fields' );	
										$user = new WP_User( $user_id );
										
										foreach ( $default_fields as $field_key => $field_value ) { ?>										
											<?php
											if(get_user_meta($user_id,$field_key,true)!=''){
											if($field_key!='description'){
												$role_access='no';
												if($myaccount_fields_array[$field_key]=='yes'){
													if(in_array('all',$field_type_roles[$field_key] )){
														$role_access='yes';
													}
													if(in_array('administrator',$field_type_roles[$field_key] )){
														$role_access='yes';
													}
													if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
														foreach ( $user->roles as $role )
															if(in_array($role,$field_type_roles[$field_key] )){
																$role_access='yes';
															}
															if('administrator'==$role){
																$role_access='yes';
															}
													}	
												}
												if($role_access=='yes'){	
												?>
												<li class="row">
												<span class="col-6 col-md-5"><?php echo esc_html($field_value); ?></span>
												<span class="col-1 col-md-1 px-0">:</span>
												<div class="col-5 col-md-6 px-0">
													<?php
														if($field_key=='phone'){
															if(get_user_meta($user_id,'hide_phone',true)!='yes'){
																echo esc_html(get_user_meta($user_id,$field_key,true));
															}
														}else{
															echo esc_html(get_user_meta($user_id,$field_key,true));
														}
													?>
													
												</div>
												</li>
											<?php
												}
											}
											}
											}	
											?>
											
										
									
								</ul>
								<div class="side-right-social">
									<h4 class="title-block"><?php esc_html_e('Social Profile', 'wpmembership'); ?></h4>
									<ul>
									
									<?php
									if(get_user_meta($user_id,'facebook',true)!=''){
									?>
									<li><a href="<?php  echo esc_url(get_user_meta($user_id,'facebook',true));  ?>/"><i class="fab fa-facebook-f"></i></a></li>	
									<?php
									}
									?>
									<?php
									if(get_user_meta($user_id,'twitter',true)!=''){
									?>
									<li><a href="<?php  echo esc_url(get_user_meta($user_id,'twitter',true));  ?>/"><i class="fab fa-twitter"></i></a></li>	
									<?php
									}
									?>
									<?php
									if(get_user_meta($user_id,'linkedin',true)!=''){
									?>
									<li><a href="<?php  echo esc_url(get_user_meta($user_id,'linkedin',true));  ?>/"><i class="fab fa-linkedin-in"></i></a></li>	
									<?php
									}
									?>
									<?php
									if(get_user_meta($user_id,'instagram',true)!=''){
									?>
									<li><a href="<?php  echo esc_url(get_user_meta($user_id,'instagram',true));  ?>/"><i class="fab fa-instagram"></i></a></li>	
									<?php
									}
									?>
										<?php
											if(get_user_meta($user_id,'pinterest',true)!=''){
									?>
									<li><a href="<?php  echo esc_url(get_user_meta($user_id,'pinterest',true));  ?>/"><i class="fab fa-pinterest"></i></a></li>	
									<?php
									}
									?>
									
										<?php
									if(get_user_meta($user_id,'youtube',true)!=''){
									?>
									<li><a href="<?php  echo esc_url(get_user_meta($user_id,'youtube',true));  ?>/"><i class="fab fa-youtube"></i></a></li>	
									<?php
									}
									?>
									
									
									
									</ul>	
								</div>
								<?php
								if(get_user_meta($user->ID,'contact_button_hide',true)!='yes'){
								?>
								<center>										
									<a class="btn btn-light-green w-60" onclick="wpmembership_email_popup('<?php echo esc_attr($user_id);?>')">
									<?php esc_html_e('Contact', 'wpmembership'); ?></a>
								</center>
								<?php
								}
								?>
							</div>
							<div class="side-right-social">
								<h3 class="title-block"><?php esc_html_e('Share This Profile', 'wpmembership'); ?></h3>
								<ul>
									<li><a href="<?php echo esc_url('//www.facebook.com/sharer/sharer.php?u');?>=<?php the_permalink();  ?>"><i class="fab fa-facebook-f"></i></a></li>									
									<li><a href="<?php echo esc_url('//www.linkedin.com/shareArticle?mini=true&url=test&title');?>=<?php the_title(); ?>&summary=&source="><i class="fab fa-linkedin-in"></i></a></li>
									<li><a href="<?php echo esc_url('//pinterest.com/pin/create/button/?url');?>=<?php the_permalink();?>&media=<?php echo esc_url($iv_profile_pic_url); ?>&description=<?php the_title(); ?>"><i class="fab fa-pinterest-p"></i></a></li>
									<li><a href="<?php echo esc_url('//twitter.com/home?status');?>=<?php the_permalink(); ?>"><i class="fab fa-twitter"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>
</div>
<?php
	$currencyCode = get_option('epjbwpmembership_api_currency');
	wp_enqueue_script('epmyaccount-script-27', WP_iv_membership_URLPATH . 'admin/files/js/public-profile.js');
	wp_localize_script('epmyaccount-script-27', 'wpmembership1', array(
	'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
	'loading_image'		=> '<img src="'.WP_iv_membership_URLPATH.'admin/files/images/loader.gif">',
	'wp_iv_directories_URLPATH'		=> WP_iv_membership_URLPATH,
	'current_user_id'	=>get_current_user_id(),
	'dirwpnonce'=> wp_create_nonce("myaccount"),
	"Please_login"=>  esc_html__('Please Login','wpmembership'), 
	'Add_to_Boobmark'=>esc_html__('Add to Boobmark', 'wpmembership' ),
	'Added_to_Boobmark'=>esc_html__('Added to Boobmark', 'wpmembership' ),	
	
	) );
	
	wp_enqueue_script('wpmembership_message', WP_iv_membership_URLPATH . 'admin/files/js/user-message.js');
	wp_localize_script('wpmembership_message', 'wpmembership_data_message', array(
		'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
		'loading_image'		=> '<img src="'.WP_iv_membership_URLPATH.'admin/files/images/loader.gif">',		
		'Please_put_your_message'=>esc_html__('Please put your name,email & message', 'wpmembership' ),
		'contact'=> wp_create_nonce("contact"),
		'listing'=> wp_create_nonce("listing"),
		) );
	
	?>	