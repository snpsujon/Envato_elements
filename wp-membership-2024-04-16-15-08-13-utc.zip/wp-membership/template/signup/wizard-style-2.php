<?php
	global $wpdb;
	wp_enqueue_script("jquery");
	wp_enqueue_script('jquery-ui-core');
	wp_enqueue_script('jquery-ui-datepicker'); 
	wp_enqueue_style('wp-iv_membership-style-signup-11', WP_iv_membership_URLPATH . 'admin/files/css/iv-bootstrap.css');
	wp_enqueue_script('iv_membership-script-signup-12', WP_iv_membership_URLPATH . 'admin/files/js/bootstrap.min.js');
	wp_enqueue_script('jquery.form-validator', WP_iv_membership_URLPATH . 'admin/files/js/jquery.form-validator.js');
	wp_enqueue_style('wp-iv_membership-inline_css_here', WP_iv_membership_URLPATH . 'admin/files/css/inline_css.css');
	wp_enqueue_style('wp-iv_membership-signup-5', WP_iv_membership_URLPATH . 'admin/files/css/signup1.css');
	wp_enqueue_style('epdirpro-stylejqueryUI-666', WP_iv_membership_URLPATH . 'admin/files/css/jquery-ui.css');
	wp_enqueue_style('datetimepicker', WP_iv_membership_URLPATH . 'admin/files/css/jquery.datetimepicker.css');
	$main_class = new WP_iv_membership;
	$api_currency= 'USD';
	if( get_option('_iv_membership_api_currency' )!=FALSE ) {
		$api_currency= get_option('_iv_membership_api_currency' );
	}
	if(isset($_REQUEST['payment_gateway'])){
		$payment_gateway=sanitize_text_field($_REQUEST['payment_gateway']);
		if($payment_gateway=='paypal'){
		}
	}
	$iv_gateway='paypal-express';
	if( get_option( 'iv_membership_payment_gateway' )!=FALSE ) {
		$iv_gateway = get_option('iv_membership_payment_gateway');
		if($iv_gateway=='paypal-express'){
			$post_name='iv_membership_paypal_setting';
			$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_name = '%s' ",$post_name ));
			$paypal_id='0';
			if(isset($row->ID)){
				$paypal_id= $row->ID;
			}
			$api_currency=get_post_meta($paypal_id, 'iv_membership_paypal_api_currency', true);
			if($api_currency==''){$api_currency= 'USD';}
		}
	}
	$package_id='';
	if(isset($_REQUEST['package_id'])){
		$package_id=sanitize_text_field($_REQUEST['package_id']);
		$recurring= get_post_meta($package_id, 'iv_membership_package_recurring', true);
		if($recurring == 'on'){
			$package_amount=get_post_meta($package_id, 'iv_membership_package_recurring_cost_initial', true);
			}else{
			$package_amount=get_post_meta($package_id, 'iv_membership_package_cost',true);
		}
		if($package_amount=='' || $package_amount=='0' ){$iv_gateway='paypal-express';}
	}
	$form_meta_data= get_post_meta( $package_id,'iv_membership_content',true);
	$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->posts WHERE id = '%s' ",$package_id ));
	$package_name='';
	$package_amount='';
	if(isset($row->post_title)){
		$package_name=$row->post_title;
		$count =get_post_meta($package_id, 'iv_membership_package_recurring_cycle_count', true);
		$package_name=$package_name;
		$package_amount=get_post_meta($package_id, 'iv_membership_package_cost',true);
	}
	$newpost_id='';
	$args = array(
	'post_type' => 'iv_payment_setting',
	'posts_per_page'=> '999',
	'post_status' => 'draft',
	);
	$ep_query = new WP_Query( $args );
	if ( $ep_query->have_posts() ) :
	while ( $ep_query->have_posts() ) : $ep_query->the_post();
	$pid = get_the_ID();
	if(get_the_title($pid)==='iv_membership_stripe_setting'){
		$newpost_id = get_the_ID();
	}
	endwhile;
	endif;
	$stripe_mode=get_post_meta( $newpost_id,'iv_membership_stripe_mode',true);
	if($stripe_mode=='test'){
		$stripe_publishable =get_post_meta($newpost_id, 'iv_membership_stripe_publishable_test',true);
		}else{
		$stripe_publishable =get_post_meta($newpost_id, 'iv_membership_stripe_live_publishable_key',true);
	}
	$eprecaptcha_api=get_option( 'eprecaptcha_api');
?>
<div class="bootstrap-wrapper">
	<div id="iv-form3" class="content">
		<?php
			if($iv_gateway=='paypal-express'){
			?>
			<form id="iv_membership_registration" name="iv_membership_registration" class="form-horizontal" action="<?php  the_permalink() ?>?package_id=<?php echo esc_html($package_id); ?>&payment_gateway=paypal&iv-submit-listing=register" method="post" role="form" enctype="multipart/form-data">
				<?php
				}
				if($iv_gateway=='stripe'){?>
				<form id="iv_membership_registration" name="iv_membership_registration" class="form-horizontal" action="<?php  the_permalink() ?>?&package_id=<?php echo esc_html($package_id); ?>&payment_gateway=stripe&iv-submit-stripe=register" method="post" role="form" enctype="multipart/form-data">
					<input type="hidden" name="payment_gateway" id="payment_gateway" value="stripe">
					<input type="hidden" name="iv-submit-stripe" id="iv-submit-stripe" value="register" >
					<?php
					}
					if($iv_gateway=='woocommerce'){
					?>
					<form id="iv_membership_registration" name="iv_membership_registration" class="form-horizontal" action="<?php  the_permalink() ?>?package_id=<?php echo esc_html($package_id); ?>&payment_gateway=woocommerce&iv-submit-listing=register" method="post" enctype="multipart/form-data" role="form">
						<?php
						}
					?>
					<div class="row">													
						<h2 class="header-profile"><div><?php  esc_html_e('User Info','wpmembership');?></div></h2>
					</div>
					<div class="row">		
						<div class="col-md-2 ">
						</div>
						<div class="col-md-10 ">
							<?php
								if(isset($_REQUEST['message-error'])){?>
								<div class="row alert alert-info alert-dismissable" id='loading-2'><a class="panel-close close" data-dismiss="alert">x</a> <?php  echo esc_html($_REQUEST['message-error']); ?></div>
								<?php
								}
							?>
						</div>
					</div>	
					<!--
						For Form Validation we used plugins http://formvalidator.net/index.html#reg-form
						This is in line validation so you can add fields easily.
					-->
					<div class="text-center" id="loading"> </div>							
					<div class="form-group row"  >
						<label for="text" class="col-md-4 control-label"><?php  esc_html_e('User Name','wpmembership');?><span class="chili"></span></label>
						<div class="col-md-8">
							<input type="text"  name="iv_member_user_name" id="iv_member_user_name"  data-validation="length alphanumeric"
							data-validation-length="4-12" data-validation-error-msg="<?php  esc_html_e('The user name has to be an alphanumeric value between 4-12 characters','wpmembership');?>" class="form-input col-md-12" placeholder="<?php  esc_html_e('Enter User Name','wpmembership');?>"  alt="required">
						</div>
					</div>
					<div class="form-group row">
						<label for="email" class="col-md-4 control-label" ><?php  esc_html_e('Email Address','wpmembership');?><span class="chili"></span></label>
						<div class="col-md-8">
							<input type="email" name="iv_member_email" id="iv_member_email" data-validation="email"  class="form-input col-md-12" placeholder="<?php  esc_html_e('Enter email address','wpmembership');?>" data-validation-error-msg=" <?php  esc_html_e('Please enter a valid email address.','wpmembership');?>" >
						</div>
					</div>
					<div class="form-group row ">
						<label for="text" class="col-md-4 control-label"><?php  esc_html_e('Password','wpmembership');?><span class="chili"></span></label>
						<div class="col-md-8">
							<input type="password" name="iv_member_password"  id="iv_member_password" class="form-input col-md-12" placeholder="" data-validation="strength"
							data-validation-strength="2">
						</div>
					</div>
					<?php
						$iv_membership_signup_profile_pic=get_option('iv_membership_signup_profile_pic');
						if($iv_membership_signup_profile_pic=='' ){ $iv_membership_signup_profile_pic='yes';}	
						if($iv_membership_signup_profile_pic=='yes' ){
						?>
						<div class="form-group row ">
							<label for="text" class="col-md-4 control-label"><?php  esc_html_e('Profile Image','wpmembership');?></label>
							<div class="col-md-8">
								<input type="file" name="profilepicture"  id="profilepicture" size="25" class="form-input " />
							</div>
						</div>
						<?php
						}
					?>
					<?php
						$i=1;
						$default_fields = array();
						$default_fields=get_option('iv_membership_profile_fields');
						$sign_up_array=get_option( 'iv_membership_signup_fields');
						$require_array=get_option( 'iv_membership_signup_require');
						if(is_array($default_fields)){
							foreach ( $default_fields as $field_key => $field_value ) {
								$sign_up='no';
								if(isset($sign_up_array[$field_key]) && $sign_up_array[$field_key] == 'yes') {
									$sign_up='yes';
								}
								$require='no';
								if(isset($require_array[$field_key]) && $require_array[$field_key] == 'yes') {
									$require='yes';
								}
								if($sign_up=='yes--'){
								?>
								<div class="form-group row">
									<label  class="col-md-4 control-label" ><?php echo esc_html($field_value); ?><span class="<?php echo($require=='yes'?'chili':''); ?>"></span></label>
									<div class="col-md-8">
										<input type="text"  name="<?php echo esc_html($field_key);?>" <?php echo($require=='yes'?'data-validation="length" data-validation-length="2-100"':''); ?>
										class="form-control ctrl-textbox" placeholder="<?php esc_html_e('Enter', 'wpmembership');?><?php echo esc_html($field_value);?>" >
									</div>
								</div>
								<?php
								}
								echo  $main_class->iv_membership_check_field_input_access_signup($field_key, $field_value);
							}
						}
					?>
					<?php
						$tax_type= (get_option('_iv_tax_type')!=""?get_option('_iv_tax_type'):"country");
						$tax_active_module=get_option('_iv_membership_active_tax');
						if($tax_active_module=='' ){ $tax_active_module='yes';	}
						$country_show=0;
						if($tax_type=='country'){
							$country_show=1;
							}else{
							$country_show=0;
						}
						if($tax_active_module=='yes' AND $country_show==1){
						?>
						<div class="form-group row">
							<label class="col-md-4 control-label"><?php  esc_html_e('Country[Tax]','wpmembership');?><span class="chili"></span></label>
							<div class="col-md-8">
								<select name="country_select" id ="country_select" class=" form-deopdown col-md-12" data-validation="required"
								data-validation-error-msg="<?php  esc_html_e('Please select your country','medico');?>">
									<?php
										$countries = array(
										"AF" => "Afghanistan (‫افغانستان‬‎)",
										"AX" => "Åland Islands (Åland)",
										"AL" => "Albania (Shqipëri)",
										"DZ" => "Algeria (‫الجزائر‬‎)",
										"AS" => "American Samoa",
										"AD" => "Andorra",
										"AO" => "Angola",
										"AI" => "Anguilla",
										"AQ" => "Antarctica",
										"AG" => "Antigua and Barbuda",
										"AR" => "Argentina",
										"AM" => "Armenia (Հայաստան)",
										"AW" => "Aruba",
										"AC" => "Ascension Island",
										"AU" => "Australia",
										"AT" => "Austria (Österreich)",
										"AZ" => "Azerbaijan (Azərbaycan)",
										"BS" => "Bahamas",
										"BH" => "Bahrain (‫البحرين‬‎)",
										"BD" => "Bangladesh (বাংলাদেশ)",
										"BB" => "Barbados",
										"BY" => "Belarus (Беларусь)",
										"BE" => "Belgium (België)",
										"BZ" => "Belize",
										"BJ" => "Benin (Bénin)",
										"BM" => "Bermuda",
										"BT" => "Bhutan (འབྲུག)",
										"BO" => "Bolivia",
										"BA" => "Bosnia and Herzegovina (Босна и Херцеговина)",
										"BW" => "Botswana",
										"BV" => "Bouvet Island",
										"BR" => "Brazil (Brasil)",
										"IO" => "British Indian Ocean Territory",
										"VG" => "British Virgin Islands",
										"BN" => "Brunei",
										"BG" => "Bulgaria (България)",
										"BF" => "Burkina Faso",
										"BI" => "Burundi (Uburundi)",
										"KH" => "Cambodia (កម្ពុជា)",
										"CM" => "Cameroon (Cameroun)",
										"CA" => "Canada",
										"IC" => "Canary Islands (islas Canarias)",
										"CV" => "Cape Verde (Kabu Verdi)",
										"BQ" => "Caribbean Netherlands",
										"KY" => "Cayman Islands",
										"CF" => "Central African Republic (République centrafricaine)",
										"EA" => "Ceuta and Melilla (Ceuta y Melilla)",
										"TD" => "Chad (Tchad)",
										"CL" => "Chile",
										"CN" => "China (中国)",
										"CX" => "Christmas Island",
										"CP" => "Clipperton Island",
										"CC" => "Cocos (Keeling) Islands (Kepulauan Cocos (Keeling))",
										"CO" => "Colombia",
										"KM" => "Comoros (‫جزر القمر‬‎)",
										"CD" => "Congo (DRC) (Jamhuri ya Kidemokrasia ya Kongo)",
										"CG" => "Congo (Republic) (Congo-Brazzaville)",
										"CK" => "Cook Islands",
										"CR" => "Costa Rica",
										"CI" => "Côte d’Ivoire",
										"HR" => "Croatia (Hrvatska)",
										"CU" => "Cuba",
										"CW" => "Curaçao",
										"CY" => "Cyprus (Κύπρος)",
										"CZ" => "Czech Republic (Česká republika)",
										"DK" => "Denmark (Danmark)",
										"DG" => "Diego Garcia",
										"DJ" => "Djibouti",
										"DM" => "Dominica",
										"DO" => "Dominican Republic (República Dominicana)",
										"EC" => "Ecuador",
										"EG" => "Egypt (‫مصر‬‎)",
										"SV" => "El Salvador",
										"GQ" => "Equatorial Guinea (Guinea Ecuatorial)",
										"ER" => "Eritrea",
										"EE" => "Estonia (Eesti)",
										"ET" => "Ethiopia",
										"FK" => "Falkland Islands (Islas Malvinas)",
										"FO" => "Faroe Islands (Føroyar)",
										"FJ" => "Fiji",
										"FI" => "Finland (Suomi)",
										"FR" => "France",
										"GF" => "French Guiana (Guyane française)",
										"PF" => "French Polynesia (Polynésie française)",
										"TF" => "French Southern Territories (Terres australes françaises)",
										"GA" => "Gabon",
										"GM" => "Gambia",
										"GE" => "Georgia (საქართველო)",
										"DE" => "Germany (Deutschland)",
										"GH" => "Ghana (Gaana)",
										"GI" => "Gibraltar",
										"GR" => "Greece (Ελλάδα)",
										"GL" => "Greenland (Kalaallit Nunaat)",
										"GD" => "Grenada",
										"GP" => "Guadeloupe",
										"GU" => "Guam",
										"GT" => "Guatemala",
										"GG" => "Guernsey",
										"GN" => "Guinea (Guinée)",
										"GW" => "Guinea-Bissau (Guiné Bissau)",
										"GY" => "Guyana",
										"HT" => "Haiti",
										"HM" => "Heard & McDonald Islands",
										"HN" => "Honduras",
										"HK" => "Hong Kong (香港)",
										"HU" => "Hungary (Magyarország)",
										"IS" => "Iceland (Ísland)",
										"IN" => "India (भारत)",
										"ID" => "Indonesia",
										"IR" => "Iran (‫ایران‬‎)",
										"IQ" => "Iraq (‫العراق‬‎)",
										"IE" => "Ireland",
										"IM" => "Isle of Man",
										"IL" => "Israel (‫ישראל‬‎)",
										"IT" => "Italy (Italia)",
										"JM" => "Jamaica",
										"JP" => "Japan (日本)",
										"JE" => "Jersey",
										"JO" => "Jordan (‫الأردن‬‎)",
										"KZ" => "Kazakhstan (Казахстан)",
										"KE" => "Kenya",
										"KI" => "Kiribati",
										"XK" => "Kosovo (Kosovë)",
										"KW" => "Kuwait (‫الكويت‬‎)",
										"KG" => "Kyrgyzstan (Кыргызстан)",
										"LA" => "Laos (ລາວ)",
										"LV" => "Latvia (Latvija)",
										"LB" => "Lebanon (‫لبنان‬‎)",
										"LS" => "Lesotho",
										"LR" => "Liberia",
										"LY" => "Libya (‫ليبيا‬‎)",
										"LI" => "Liechtenstein",
										"LT" => "Lithuania (Lietuva)",
										"LU" => "Luxembourg",
										"MO" => "Macau (澳門)",
										"MK" => "Macedonia (FYROM) (Македонија)",
										"MG" => "Madagascar (Madagasikara)",
										"MW" => "Malawi",
										"MY" => "Malaysia",
										"MV" => "Maldives",
										"ML" => "Mali",
										"MT" => "Malta",
										"MH" => "Marshall Islands",
										"MQ" => "Martinique",
										"MR" => "Mauritania (‫موريتانيا‬‎)",
										"MU" => "Mauritius (Moris)",
										"YT" => "Mayotte",
										"MX" => "Mexico (México)",
										"FM" => "Micronesia",
										"MD" => "Moldova (Republica Moldova)",
										"MC" => "Monaco",
										"MN" => "Mongolia (Монгол)",
										"ME" => "Montenegro (Crna Gora)",
										"MS" => "Montserrat",
										"MA" => "Morocco (‫المغرب‬‎)",
										"MZ" => "Mozambique (Moçambique)",
										"MM" => "Myanmar (Burma) (မြန်မာ)",
										"NA" => "Namibia (Namibië)",
										"NR" => "Nauru",
										"NP" => "Nepal (नेपाल)",
										"NL" => "Netherlands (Nederland)",
										"NC" => "New Caledonia (Nouvelle-Calédonie)",
										"NZ" => "New Zealand",
										"NI" => "Nicaragua",
										"NE" => "Niger (Nijar)",
										"NG" => "Nigeria",
										"NU" => "Niue",
										"NF" => "Norfolk Island",
										"MP" => "Northern Mariana Islands",
										"KP" => "North Korea (조선 민주주의 인민 공화국)",
										"NO" => "Norway (Norge)",
										"OM" => "Oman (‫عُمان‬‎)",
										"PK" => "Pakistan (‫پاکستان‬‎)",
										"PW" => "Palau",
										"PS" => "Palestine (‫فلسطين‬‎)",
										"PA" => "Panama (Panamá)",
										"PG" => "Papua New Guinea",
										"PY" => "Paraguay",
										"PE" => "Peru (Perú)",
										"PH" => "Philippines",
										"PN" => "Pitcairn Islands",
										"PL" => "Poland (Polska)",
										"PT" => "Portugal",
										"PR" => "Puerto Rico",
										"QA" => "Qatar (‫قطر‬‎)",
										"RE" => "Réunion (La Réunion)",
										"RO" => "Romania (România)",
										"RU" => "Russia (Россия)",
										"RW" => "Rwanda",
										"BL" => "Saint Barthélemy (Saint-Barthélemy)",
										"SH" => "Saint Helena",
										"KN" => "Saint Kitts and Nevis",
										"LC" => "Saint Lucia",
										"MF" => "Saint Martin (Saint-Martin (partie française))",
										"PM" => "Saint Pierre and Miquelon (Saint-Pierre-et-Miquelon)",
										"WS" => "Samoa",
										"SM" => "San Marino",
										"ST" => "São Tomé and Príncipe (São Tomé e Príncipe)",
										"SA" => "Saudi Arabia (‫المملكة العربية السعودية‬‎)",
										"SN" => "Senegal (Sénégal)",
										"RS" => "Serbia (Србија)",
										"SC" => "Seychelles",
										"SL" => "Sierra Leone",
										"SG" => "Singapore",
										"SX" => "Sint Maarten",
										"SK" => "Slovakia (Slovensko)",
										"SI" => "Slovenia (Slovenija)",
										"SB" => "Solomon Islands",
										"SO" => "Somalia (Soomaaliya)",
										"ZA" => "South Africa",
										"GS" => "South Georgia & South Sandwich Islands",
										"KR" => "South Korea (대한민국)",
										"SS" => "South Sudan (‫جنوب السودان‬‎)",
										"ES" => "Spain (España)",
										"LK" => "Sri Lanka (ශ්‍රී ලංකාව)",
										"VC" => "St. Vincent & Grenadines",
										"SD" => "Sudan (‫السودان‬‎)",
										"SR" => "Suriname",
										"SJ" => "Svalbard and Jan Mayen (Svalbard og Jan Mayen)",
										"SZ" => "Swaziland",
										"SE" => "Sweden (Sverige)",
										"CH" => "Switzerland (Schweiz)",
										"SY" => "Syria (‫سوريا‬‎)",
										"TW" => "Taiwan (台灣)",
										"TJ" => "Tajikistan",
										"TZ" => "Tanzania",
										"TH" => "Thailand (ไทย)",
										"TL" => "Timor-Leste",
										"TG" => "Togo",
										"TK" => "Tokelau",
										"TO" => "Tonga",
										"TT" => "Trinidad and Tobago",
										"TA" => "Tristan da Cunha",
										"TN" => "Tunisia (‫تونس‬‎)",
										"TR" => "Turkey (Türkiye)",
										"TM" => "Turkmenistan",
										"TC" => "Turks and Caicos Islands",
										"TV" => "Tuvalu",
										"UM" => "U.S. Outlying Islands",
										"VI" => "U.S. Virgin Islands",
										"UG" => "Uganda",
										"UA" => "Ukraine (Україна)",
										"AE" => "United Arab Emirates (‫الإمارات العربية المتحدة‬‎)",
										"GB" => "United Kingdom",
										"US" => "United States",
										"UY" => "Uruguay",
										"UZ" => "Uzbekistan (Oʻzbekiston)",
										"VU" => "Vanuatu",
										"VA" => "Vatican City (Città del Vaticano)",
										"VE" => "Venezuela",
										"VN" => "Vietnam (Việt Nam)",
										"WF" => "Wallis and Futuna",
										"EH" => "Western Sahara (‫الصحراء الغربية‬‎)",
										"YE" => "Yemen (‫اليمن‬‎)",
										"ZM" => "Zambia",
										"ZW" => "Zimbabwe");
										$i=0;
										echo '<option value="" >'. esc_html__( 'Select Country','medico').'</option>';
										$first_country='select';
										foreach($countries as $key=>$country) {
											echo '<option value="'. esc_html($key).'" >'. esc_html($country).'</option>';
											$i++;
										}
									?>
								</select>
							</div>
						</div>
						<?php
						}
					?>
					<?php
						$iv_membership_pack='iv_membership_pack';
						$sql=$wpdb->prepare("SELECT * FROM $wpdb->posts WHERE post_type = '%s'  and post_status='draft' ",$iv_membership_pack );
						$membership_pack = $wpdb->get_results($sql);
						$total_package = count($membership_pack);
						if(sizeof($membership_pack)<1){ ?>
							<input type="hidden" name="reg_error" id="reg_error" value="yes">
							<input type="hidden" name="package_id" id="package_id" value="0">
							<input type="hidden" name="return_page" id="return_page" value="<?php  the_permalink() ?>">
							<div class="row">
								<div class="col-md-4">
								</div>
								<div class="col-md-8 ">
									<div id="paypal-button" class="margin-top-20">
										<div id="loading-3"><img src='<?php echo WP_iv_membership_URLPATH. 'admin/files/images/loader.gif'; ?>' /></div>														
										
										<?php				
									if($eprecaptcha_api==''){?>
									
									<button  id="submit_iv_membership_payment" name="submit_iv_membership_payment"  type="submit" class="btn btn-info ctrl-btn"  > <?php  esc_html_e('Submit','wpmembership');?></button>
									<?php
									}else{
									?>					
										<button  id="submit_iv_membership_payment" name="submit_iv_membership_payment"  type="submit" class="btn btn-info ctrl-btn g-recaptcha" data-sitekey="<?php echo esc_html($eprecaptcha_api); ?>"  data-callback='epluginrecaptchaSubmit' data-action='submit' > <?php  esc_html_e('Submit','wpmembership');?></button>
									<?php
									}
									?>
										
										
									</div>
								</div>
							</div>
					
						<?php
						}
						?>
					<input type="hidden" name="hidden_form_name" id="hidden_form_name" value="iv_membership_registration">
					<?php
						if(sizeof($membership_pack)>0){
					?>	
					
					<div class="row">
						<div class="col-md-12 ">
							<h2 class="header-profile"><div><?php  esc_html_e('Payment Info','wpmembership');?></div></h2>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 ">
							<?php
								if($iv_gateway=='paypal-express'){
									require_once(WP_iv_membership_template.'signup/paypal_form_2.php');
								}
								if($iv_gateway=='stripe'){
									require_once(WP_iv_membership_template.'signup/iv_stripe_form_2.php');
								}
								if($iv_gateway=='woocommerce'){
									include(WP_iv_membership_template.'signup/woocommerce.php');
								}
							?>
						</div>
					</div>
					<?php
						}
					?>
					
					<div id="errormessage" class="alert alert-danger mt-2 displaynone" role="alert"></div>
				</form>
				<div class="dnone">
					<img src='<?php echo WP_iv_membership_URLPATH. 'admin/files/images/loader.gif'; ?>' />
				</div>
			</div>
		</div>
		<?php	
			wp_enqueue_script('wp-iv_membership-script-30', WP_iv_membership_URLPATH . 'admin/files/js/signup.js');
			wp_localize_script('wp-iv_membership-script-30', 'epsignup_data', array(
			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
			'loader_image'=>'<img src="'.WP_iv_membership_URLPATH. 'admin/files/images/loader.gif" />',
			'loader_image2'=>'<img src="'.WP_iv_membership_URLPATH. 'admin/files/images/old-loader.gif" />',
			'right_icon'=>'<img src="'.WP_iv_membership_URLPATH. 'admin/files/images/right_icon.png" />',
			'wrong_16x16'=>'<img src="'.WP_iv_membership_URLPATH. 'admin/files/images/wrong_16x16.png" />',
			'stripe_publishable'=>$stripe_publishable,
			'package_amount'=>$package_amount,
			'api_currency'=>$api_currency,
			'iv_gateway'=>$iv_gateway,
			'errormessage'=>esc_html__("Please complete the form",'wpmembership'),
			'HideCoupon'=>esc_html__("Hide Coupon",'wpmembership'),
			'Havecoupon'=>esc_html__("Have a coupon?",'wpmembership'),
			'dirwpnonce'=> wp_create_nonce("signup"),
			'signup'=> wp_create_nonce("signup"),
			) );
			if($eprecaptcha_api!=''){	
				wp_register_script( 'rechaptcha', 'https://www.google.com/recaptcha/api.js?render='.$eprecaptcha_api, null, null, true );
				wp_enqueue_script('rechaptcha');
			}
		?>						