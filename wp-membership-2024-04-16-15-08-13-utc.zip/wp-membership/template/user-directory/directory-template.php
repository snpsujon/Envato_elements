<?php
	global $post;
	wp_enqueue_script('jquery');
	wp_enqueue_script('jquery-ui');
	wp_enqueue_style('all-awesome', WP_iv_membership_URLPATH . 'admin/files/css/all.min.css');
	wp_enqueue_style('bootstrap-style-11', WP_iv_membership_URLPATH . 'admin/files/css/iv-bootstrap-4.css');
	
	wp_enqueue_script('wpmembership-script-user-directory', WP_iv_membership_URLPATH . 'admin/files/js/user-directory.js');
	/**************************** css resources from qdesk ********************************************/
	
	wp_enqueue_style('mCustomScrollbar', WP_iv_membership_URLPATH . 'admin/files/css/jquery.mCustomScrollbar.css');
	wp_enqueue_style('main-css', WP_iv_membership_URLPATH . 'admin/files/css/main.css');
	wp_enqueue_script('mCustomScrollbarJS', WP_iv_membership_URLPATH . 'admin/files/js/jquery.mCustomScrollbar.concat.min.js');
	
	wp_enqueue_script('isotope', WP_iv_membership_URLPATH . 'admin/files/js/isotope.pkgd.min.js');
	

	/**************************************************************************************************/
	$main_class = new WP_iv_membership;
	
?>
<div class="bootstrap-wrapper wrapper" id="wrapper">
    <form method="GET" action="<?php echo get_permalink($post->ID); ?>">
		<main class="main-content">
			<div class="primary-page">
				<div class="container">
					<div class="header-page">
							<div class="row">
								<div class="col-md-6"></div>
								<div class="col-md-6 input-group mb-3 search-form mt-4">
									  <input type="text" class="form-control " name="user_name_search" value="<?php echo (isset($_REQUEST['user_name_search'])? esc_attr($_REQUEST['user_name_search']) :'');?>" placeholder="<?php esc_html_e('Search...','wpmembership'); ?>" >
									  <div class="input-group-append">
										<button class="btn btn-light"><i class="fa fa-search"></i></button>
									  </div>
									</div>
								</div>
									
					</div>
					<div class="row">
						<div class="col-md-4"> 
						
							<div class="box-sidebar">
								<div class="header-box d-flex justify-content-between flex-wrap">
									<h4 class="title-box"><?php esc_html_e('Locations','wpmembership'); ?></h4>
									<div class="search">
										<i class="fa fa-search"></i>                       
									</div>
								</div>
								<div class="body-box">
									<ul class="list-check-filter-job">
										<?php
											$locations=array();
											$args_location = array();
											$args_location['number']='9999999';
											
											$user_query_location = new WP_User_Query( $args_location );
											if ( ! empty( $user_query_location->results ) ) {
												foreach ( $user_query_location->results as $user_location ) {						
													if(get_user_meta($user_location->ID,'city',true)!=""){
														$c_location=ucwords(get_user_meta($user_location->ID,'city',true)).', '.ucwords(get_user_meta($user_location->ID,'country',true));							
														if(!in_array($c_location, $locations)){							
															array_push($locations, $c_location);
														}
													}
													// Update full name
													if(trim(get_user_meta($user_location->ID,'full_name',true))==""){
														update_user_meta($user_location->ID,'full_name',$user_location->display_name);
													}
												}
											}	
											$location_input_array= array();
											if(isset($_REQUEST['location_input'])){
												$location_input_array=$_REQUEST['location_input'];
											}
											$i=0;	
											foreach($locations as $one_location){
												$selected='';
												if(in_array($one_location, $location_input_array)){
													$selected='checked="checked"';
												}
											?>
											<li>
												<div class="custom-control custom-checkbox">
													<input class="custom-control-input" type="checkbox" id="location_<?php echo esc_attr($i); ?>" name="location_input[]"  value="<?php echo esc_attr($one_location); ?>" <?php echo esc_attr($selected); ?> >
													<label class="custom-control-label" for="location_<?php echo esc_attr($i); ?>"><?php echo esc_html($one_location); ?> </label>
												</div>
											</li>						   
											<?php
												$i++;
											}
										?>
									</ul>
								</div>
								<button type="submit"  class="btn btn-light-green col-md-12 "><?php esc_html_e('Search ', 'wpmembership'); ?></button>
							</div>
						</div>
						<?php
							if(isset($atts['per_page'])){
								$users_per_page=$atts['per_page'];
								}else{
								$users_per_page=15;
							}
							$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
							if($paged==1){
								$offset=0;  
								}else {
								$offset= ($paged-1)*$users_per_page;
							}
							$args = array();
							$args['number']=$users_per_page;
							$args['offset']= $offset; 
							$args['orderby']='display_name';
							$args['order']='ASC'; 
							if(isset($atts['role'])){
								$args['role']=$atts['role'];
							}
							$location_city_arr= array();							
							$location_input_array= array();
							
							if(isset($_REQUEST['location_input'])){
								$location_input_array=$_REQUEST['location_input'];
								foreach($location_input_array as $one_value){										
										$city_counrty= explode(',',$one_value);
										$location_city_arr[]=$city_counrty[0];
								}
								
							}
														
							$user_name_search='';
							if( isset($_REQUEST['user_name_search'])){								
								if($_REQUEST['user_name_search']!=""){
										$user_name_search = array(
										'relation' => 'or',
											array(
												'key'     => 'first_name',
												'value'   => sanitize_text_field($_REQUEST['user_name_search']),
												'compare' => 'LIKE'
											),
											array(
												'key'     => 'last_name',
												'value'   => sanitize_text_field($_REQUEST['user_name_search']),
												'compare' => 'LIKE'
											),
										);
								}
							}
											
							$city_search='';
							if( isset($_REQUEST['location_input'])){								
								if($_REQUEST['location_input']!=""){
										$city_search = array(
										'relation' => 'AND',
											array(
												'key'     => 'city',
												'value'   => $location_city_arr,
												'compare' => 'IN'
											),
										);
								}
							}
							
							
							
							
							$args['meta_query'] = array(
								$user_name_search,$city_search,
							);
							
							$user_query = new WP_User_Query( $args );
							$total_users = $user_query->get_total();	
						?>
						<div class="col-md-8">
							<div class="content-main-right list-jobs">
								<div class="header-list-job d-flex flex-wrap justify-content-between align-items-center">
									<h4><?php echo esc_html($total_users); ?> <?php esc_html_e('Users Found', 'wpmembership'); ?> </h4>
								</div>
								<div class="list">
									<?php				    
										// User Loop
										if ( ! empty( $user_query->results ) ) {
											foreach ( $user_query->results as $user ) {
											
												$profile_page=get_option('_iv_membership_profile_public_page');
												$page_link= get_permalink( $profile_page).'?&id='.$user->ID; 
												$full_name=$user->display_name;
												if(get_user_meta($user->ID,'first_name',true)!=''){
													$full_name=get_user_meta($user->ID,'first_name',true).' '.get_user_meta($user->ID,'last_name',true);
												}
											?>
											<div class="job-item employer">
												<div class="row">
													<div class="col-md-2 pr-0">
														<a href="<?php  echo esc_url($page_link); ?>">
														<?php
															$iv_profile_pic_url=get_user_meta($user->ID, 'iv_profile_pic_thum',true);
															if($iv_profile_pic_url!=''){ ?>
															<img  src="<?php echo esc_url($iv_profile_pic_url); ?>">
															<?php
																}else{
																echo'<img src="'. WP_iv_membership_URLPATH.'assets/images/default-user.png">';
															}
														?>
															
														</a>
													</div>
													<div class="col-md-10">
														<div class="row">
															<div class="col-md-12">
																<h3 class="title-job">
																	<a href="<?php  echo esc_url($page_link); ?>">
																	<?php echo esc_html($full_name); ?>
																	</a>
																</h3>
															</div>
															<div class="meta-job col-md-12">
																<p><i class="fa fa-check-circle"></i><span class="p-1"> </span><?php esc_html_e('Member Since', 'wpmembership'); ?>
																	<?php echo date('M d, Y', strtotime($user->user_registered)); ?>
																</p>
																<?php
																	if(get_user_meta($user->ID,'address',true)!='' OR get_user_meta($user->ID,'city',true)!='' ){
																	?>
																	<p class="location"><i class="far fa-map"></i>  <?php echo get_user_meta($user->ID,'address',true); ?> <?php echo get_user_meta($user->ID,'city',true); ?>, <?php echo get_user_meta($user->ID,'zipcode',true); ?>,<?php echo get_user_meta($user->ID,'country',true); ?></p>
																	<?php
																	}
																?>
																
															</div>
															
														</div>
													</div>
												</div>
											</div>
											<?php
											}
										}
									?>				
								</div>				
								<?php
									
									$params =array();
									$pages = paginate_links( array_merge( [
									'base'         => str_replace( $post->ID, '%#%', esc_url( get_pagenum_link( $post->ID ) ) ),
									'format'       => '?paged=%#%',
									'current'      => max( 1, get_query_var( 'paged' ) ),
									'total'        => round((int)$total_users/$users_per_page),
									'type'         => 'array',
									'show_all'     => false,
									'end_size'     => 3,
									'mid_size'     => 1,
									'prev_next'    => true,
									'prev_text'    => esc_html__( '« Prev','wpmembership' ),
									'next_text'    => esc_html__( 'Next »','wpmembership' ),
									'add_args'     => $args,
									'add_fragment' => ''
									], $params )
									);			 				
									if ( is_array( $pages ) ) {			
										$pagination = '<div class=" mt-3 pagination justify-content-center"><ul class="pagination">';												
										foreach ( $pages as $page ) {
											$pagination .= '<li class="page-item' . (strpos($page, 'current') !== false ? ' active' : '') . '"> ' . str_replace('page-numbers', 'page-link', $page) . '</li>';
										}
										$pagination .= '</ul></div>';
										echo wp_specialchars_decode($pagination);
									}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
	</form>
</div>